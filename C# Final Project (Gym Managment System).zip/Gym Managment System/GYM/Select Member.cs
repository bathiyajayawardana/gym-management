﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace GYM
{
    public partial class Select_Member : Form
    {
        public Select_Member()
        {
            InitializeComponent();
        }

        //close
        private void labelClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void labelClose_MouseEnter(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.White;
        }

        private void labelClose_MouseLeave(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.Black; ;
        }

        //minimized
        private void labelminimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void labelminimize_MouseEnter(object sender, EventArgs e)
        {
            labelminimize.ForeColor = Color.White;
        }

        private void labelminimize_MouseLeave(object sender, EventArgs e)
        {
            labelminimize.ForeColor = Color.Black;
        }

        private void Select_Member_Load(object sender, EventArgs e)
        {
            // display the logged admin members list 
            MySqlCommand command = new MySqlCommand("SELECT `mid`, `mfname`, `mlname`,`sid` as 'sid' FROM `members` WHERE `aid`=@aid");
            command.Parameters.Add("@aid", MySqlDbType.Int32).Value = GLOBAL.GlobaluserId;

            MEMBERS mem = new MEMBERS();

            dataGridView1.DataSource = mem.selectMemberList(command);
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
