﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace GYM
{
    class SESSIONS
    {
        wzone wz = new wzone();

        //fuction to add a session to the logged in user
        public bool insertSession(string sname, int aid)
        {

            MySqlCommand command = new MySqlCommand("INSERT INTO `sessions`( `sname`, `aid`) VALUES (@sn,@aid)", wz.getConnection);

            command.Parameters.Add("@sn", MySqlDbType.VarChar).Value = sname;
            command.Parameters.Add("@aid", MySqlDbType.Int32).Value = aid;

            wz.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                wz.closeConnection();
                return true;
            }
            else
            {
                wz.closeConnection();
                return false;
            }

        }

        // check if the session name already exists
        public bool sessionExists(string sname, string operation, int aid=0, int sid=0)
        {
            string query = "";
            MySqlCommand command = new MySqlCommand();

            if (operation == "add")
            {
                //if the session name already exists
                query = "SELECT * FROM `sessions` WHERE `sname`=@sn AND `aid`=@aid";

                command.Parameters.Add("@sn", MySqlDbType.VarChar).Value = sname;
                command.Parameters.Add("@aid", MySqlDbType.Int32).Value = aid;
            }
            else if (operation == "Edit")
            {
                // check if the user enter a session name that already exists (not including the current session name)
                query = "SELECT * FROM `sessions` WHERE `sname`=@sn AND `aid`=@aid AND `sid`<>@sid";
                command.Parameters.Add("@sn", MySqlDbType.VarChar).Value = sname;
                command.Parameters.Add("@aid", MySqlDbType.Int32).Value = aid;
                command.Parameters.Add("@sid", MySqlDbType.Int32).Value = sid;
            }


            command.Connection = wz.getConnection;
            command.CommandText = query;

            MySqlDataAdapter adapter = new MySqlDataAdapter(command);

            DataTable table = new DataTable();

            adapter.Fill(table);
            //if the session exists return true
            if (table.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        //create a fuction to get all groups
        public DataTable getSessions(int aid)
        {
            MySqlCommand command = new MySqlCommand("SELECT * FROM `sessions` WHERE `aid`=@aid", wz.getConnection);

            command.Parameters.Add("@aid", MySqlDbType.Int32).Value = aid;

            MySqlDataAdapter adapter = new MySqlDataAdapter(command);

            DataTable table = new DataTable();

            adapter.Fill(table);

            return table;
        }

        //create a fuction to edit session name
        public bool updateSessions(int sid, string sname)
        {
            MySqlCommand command = new MySqlCommand("UPDATE `sessions` SET `sname`=@sn WHERE `sid`=@sid ", wz.getConnection);

            command.Parameters.Add("@sn", MySqlDbType.VarChar).Value = sname;
            command.Parameters.Add("@sid", MySqlDbType.Int32).Value = sid;

            wz.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                wz.closeConnection();
                return true;
            }
            else
            {
                wz.closeConnection();
                return false;
            }
        }


        //function to remove session
        public bool deleteSession(int sid)
        {
            MySqlCommand command = new MySqlCommand("DELETE FROM `sessions` WHERE `sid`=@sid", wz.getConnection);

            command.Parameters.Add("@sid", MySqlDbType.Int32).Value = sid;

            wz.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                wz.closeConnection();
                return true;
            }
            else
            {
                wz.closeConnection();
                return false;
            }
        }

    }
}
