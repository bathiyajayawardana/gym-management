﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GYM
{
    public partial class Add_Member_Details : Form
    {
        public Add_Member_Details()
        {
            InitializeComponent();
        }

        //close
        private void labelClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void labelClose_MouseEnter(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.Red;
        }

        private void labelClose_MouseLeave(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.Black;
        }

        //minimized
        private void labelminimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void labelminimize_MouseEnter(object sender, EventArgs e)
        {
            labelminimize.ForeColor = Color.Red;
        }

        private void labelminimize_MouseLeave(object sender, EventArgs e)
        {
            labelminimize.ForeColor = Color.Black;
        }

        //button to add member
        private void buttonAddMem_Click(object sender, EventArgs e)
        {
            MEMBERS mem = new MEMBERS();

            string mfname = textBoxMfn.Text;
            string mlname = textBoxMln.Text;
            string mbday = textBoxMdob.Text;
            string mgen = textBoxMgen.Text;
            string mnic = textBoxMnic.Text;
            string mphone = textBoxMphn.Text;
            string memail = textBoxMeml.Text;
            string maddrs = textBoxMaddrs.Text;
            int aid = GLOBAL.GlobaluserId;


           try
           {
                //get session id
                int sid = (int)comboBoxMses.SelectedValue;
                
                //get image 
                MemoryStream mpic = new MemoryStream();
                pictureBoxAddMemPic.Image.Save(mpic, pictureBoxAddMemPic.Image.RawFormat);

                if(mem.insertMember(mfname,mlname,mbday,mgen, mnic, mphone, memail, maddrs, mpic, sid, aid))
                {
                    MessageBox.Show("New Member Added","Add Member",MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Error","Add Member",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
           }
           catch
           {
              MessageBox.Show("One or More Fileds Are Empty","Add Member",MessageBoxButtons.OK,MessageBoxIcon.Error);
           }

        }

        //button browse image
        private void buttonAddMemPic_Click(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            opf.Filter = "Select Image (*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif";

            if (opf.ShowDialog() == DialogResult.OK)
            {
                pictureBoxAddMemPic.Image = Image.FromFile(opf.FileName);
            }
        }

        private void Add_Member_Details_Load(object sender, EventArgs e)
        {
            //populate combobox
            SESSIONS ses = new SESSIONS();
            comboBoxMses.DataSource = ses.getSessions(GLOBAL.GlobaluserId);
            comboBoxMses.DisplayMember = "sname";
            comboBoxMses.ValueMember = "sid";
        }
    }
}
