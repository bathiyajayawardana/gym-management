﻿namespace GYM
{
    partial class LOGIN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.labelminimize = new System.Windows.Forms.Label();
            this.labelClose = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lgolog = new System.Windows.Forms.Label();
            this.lgosign = new System.Windows.Forms.Label();
            this.buttonbrws = new System.Windows.Forms.Button();
            this.buttoncrt = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBoxadmin = new System.Windows.Forms.PictureBox();
            this.textBoxpass = new System.Windows.Forms.TextBox();
            this.textBoxuser = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxln = new System.Windows.Forms.TextBox();
            this.textBoxfn = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonlog = new System.Windows.Forms.Button();
            this.textBoxpw = new System.Windows.Forms.TextBox();
            this.textBoxun = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxadmin)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(167)))), ((int)(((byte)(240)))));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(437, 708);
            this.panel1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel3.Controls.Add(this.labelminimize);
            this.panel3.Controls.Add(this.labelClose);
            this.panel3.Location = new System.Drawing.Point(0, 1);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(441, 40);
            this.panel3.TabIndex = 19;
            // 
            // labelminimize
            // 
            this.labelminimize.AutoSize = true;
            this.labelminimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelminimize.Location = new System.Drawing.Point(372, 10);
            this.labelminimize.Name = "labelminimize";
            this.labelminimize.Size = new System.Drawing.Size(20, 26);
            this.labelminimize.TabIndex = 22;
            this.labelminimize.Text = "-";
            this.labelminimize.Click += new System.EventHandler(this.labelminimize_Click);
            this.labelminimize.MouseEnter += new System.EventHandler(this.labelminimize_MouseEnter);
            this.labelminimize.MouseLeave += new System.EventHandler(this.labelminimize_MouseLeave);
            // 
            // labelClose
            // 
            this.labelClose.AutoSize = true;
            this.labelClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelClose.Location = new System.Drawing.Point(398, 8);
            this.labelClose.Name = "labelClose";
            this.labelClose.Size = new System.Drawing.Size(27, 25);
            this.labelClose.TabIndex = 21;
            this.labelClose.Text = "X";
            this.labelClose.Click += new System.EventHandler(this.labelClose_Click);
            this.labelClose.MouseEnter += new System.EventHandler(this.labelClose_MouseEnter);
            this.labelClose.MouseLeave += new System.EventHandler(this.labelClose_MouseLeave);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(49)))), ((int)(((byte)(63)))));
            this.panel2.Controls.Add(this.lgolog);
            this.panel2.Controls.Add(this.lgosign);
            this.panel2.Controls.Add(this.buttonbrws);
            this.panel2.Controls.Add(this.buttoncrt);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.pictureBoxadmin);
            this.panel2.Controls.Add(this.textBoxpass);
            this.panel2.Controls.Add(this.textBoxuser);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.textBoxln);
            this.panel2.Controls.Add(this.textBoxfn);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.buttonlog);
            this.panel2.Controls.Add(this.textBoxpw);
            this.panel2.Controls.Add(this.textBoxun);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(0, 40);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(884, 729);
            this.panel2.TabIndex = 0;
            // 
            // lgolog
            // 
            this.lgolog.AutoSize = true;
            this.lgolog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lgolog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lgolog.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lgolog.Location = new System.Drawing.Point(509, 630);
            this.lgolog.Name = "lgolog";
            this.lgolog.Size = new System.Drawing.Size(299, 20);
            this.lgolog.TabIndex = 20;
            this.lgolog.Text = "Already have an Account??Login Here>>";
            this.lgolog.Click += new System.EventHandler(this.lgolog_Click);
            // 
            // lgosign
            // 
            this.lgosign.AutoSize = true;
            this.lgosign.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lgosign.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lgosign.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lgosign.Location = new System.Drawing.Point(35, 593);
            this.lgosign.Name = "lgosign";
            this.lgosign.Size = new System.Drawing.Size(293, 20);
            this.lgosign.TabIndex = 19;
            this.lgosign.Text = "Don\'t have an Account??Create Here>>";
            this.lgosign.Click += new System.EventHandler(this.lgosign_Click);
            // 
            // buttonbrws
            // 
            this.buttonbrws.BackColor = System.Drawing.Color.Gainsboro;
            this.buttonbrws.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonbrws.ForeColor = System.Drawing.Color.Black;
            this.buttonbrws.Location = new System.Drawing.Point(805, 361);
            this.buttonbrws.Name = "buttonbrws";
            this.buttonbrws.Size = new System.Drawing.Size(38, 167);
            this.buttonbrws.TabIndex = 18;
            this.buttonbrws.Text = "//";
            this.buttonbrws.UseVisualStyleBackColor = false;
            this.buttonbrws.Click += new System.EventHandler(this.buttonbrws_Click);
            // 
            // buttoncrt
            // 
            this.buttoncrt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(194)))), ((int)(((byte)(129)))));
            this.buttoncrt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttoncrt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttoncrt.ForeColor = System.Drawing.Color.White;
            this.buttoncrt.Location = new System.Drawing.Point(470, 563);
            this.buttoncrt.Name = "buttoncrt";
            this.buttoncrt.Size = new System.Drawing.Size(373, 47);
            this.buttoncrt.TabIndex = 17;
            this.buttoncrt.Text = "Create";
            this.buttoncrt.UseVisualStyleBackColor = false;
            this.buttoncrt.Click += new System.EventHandler(this.buttoncrt_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(461, 361);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 29);
            this.label9.TabIndex = 16;
            this.label9.Text = "Picture";
            // 
            // pictureBoxadmin
            // 
            this.pictureBoxadmin.BackColor = System.Drawing.Color.MistyRose;
            this.pictureBoxadmin.Location = new System.Drawing.Point(621, 361);
            this.pictureBoxadmin.Name = "pictureBoxadmin";
            this.pictureBoxadmin.Size = new System.Drawing.Size(178, 167);
            this.pictureBoxadmin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxadmin.TabIndex = 15;
            this.pictureBoxadmin.TabStop = false;
            // 
            // textBoxpass
            // 
            this.textBoxpass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(122)))), ((int)(((byte)(137)))));
            this.textBoxpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxpass.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxpass.Location = new System.Drawing.Point(621, 295);
            this.textBoxpass.Name = "textBoxpass";
            this.textBoxpass.Size = new System.Drawing.Size(218, 35);
            this.textBoxpass.TabIndex = 14;
            this.textBoxpass.UseSystemPasswordChar = true;
            // 
            // textBoxuser
            // 
            this.textBoxuser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(122)))), ((int)(((byte)(137)))));
            this.textBoxuser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxuser.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxuser.Location = new System.Drawing.Point(621, 242);
            this.textBoxuser.Name = "textBoxuser";
            this.textBoxuser.Size = new System.Drawing.Size(218, 35);
            this.textBoxuser.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(461, 295);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 29);
            this.label7.TabIndex = 12;
            this.label7.Text = "Password";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(461, 239);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(124, 29);
            this.label8.TabIndex = 11;
            this.label8.Text = "Username";
            // 
            // textBoxln
            // 
            this.textBoxln.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(122)))), ((int)(((byte)(137)))));
            this.textBoxln.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxln.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxln.Location = new System.Drawing.Point(621, 178);
            this.textBoxln.Name = "textBoxln";
            this.textBoxln.Size = new System.Drawing.Size(218, 35);
            this.textBoxln.TabIndex = 10;
            // 
            // textBoxfn
            // 
            this.textBoxfn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(122)))), ((int)(((byte)(137)))));
            this.textBoxfn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxfn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxfn.Location = new System.Drawing.Point(621, 125);
            this.textBoxfn.Name = "textBoxfn";
            this.textBoxfn.Size = new System.Drawing.Size(218, 35);
            this.textBoxfn.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(461, 178);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 29);
            this.label5.TabIndex = 8;
            this.label5.Text = "Last Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(461, 122);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(131, 29);
            this.label6.TabIndex = 7;
            this.label6.Text = "First Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(459, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(252, 37);
            this.label4.TabIndex = 6;
            this.label4.Text = "Create Account";
            // 
            // buttonlog
            // 
            this.buttonlog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(194)))), ((int)(((byte)(129)))));
            this.buttonlog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonlog.Enabled = false;
            this.buttonlog.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonlog.ForeColor = System.Drawing.Color.White;
            this.buttonlog.Location = new System.Drawing.Point(39, 263);
            this.buttonlog.Name = "buttonlog";
            this.buttonlog.Size = new System.Drawing.Size(377, 47);
            this.buttonlog.TabIndex = 5;
            this.buttonlog.Text = "Login";
            this.buttonlog.UseVisualStyleBackColor = false;
            this.buttonlog.Click += new System.EventHandler(this.buttonlog_Click);
            // 
            // textBoxpw
            // 
            this.textBoxpw.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(122)))), ((int)(((byte)(137)))));
            this.textBoxpw.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxpw.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxpw.Location = new System.Drawing.Point(194, 178);
            this.textBoxpw.Name = "textBoxpw";
            this.textBoxpw.Size = new System.Drawing.Size(218, 35);
            this.textBoxpw.TabIndex = 4;
            this.textBoxpw.UseSystemPasswordChar = true;
            this.textBoxpw.TextChanged += new System.EventHandler(this.textBoxpw_TextChanged);
            // 
            // textBoxun
            // 
            this.textBoxun.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(122)))), ((int)(((byte)(137)))));
            this.textBoxun.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxun.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxun.Location = new System.Drawing.Point(194, 125);
            this.textBoxun.Name = "textBoxun";
            this.textBoxun.Size = new System.Drawing.Size(218, 35);
            this.textBoxun.TabIndex = 3;
            this.textBoxun.TextChanged += new System.EventHandler(this.textBoxun_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(34, 178);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 29);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(34, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "Username";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(32, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(235, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Account Login";
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 10;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // LOGIN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(437, 708);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LOGIN";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LOGIN";
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxadmin)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBoxadmin;
        private System.Windows.Forms.TextBox textBoxpass;
        private System.Windows.Forms.TextBox textBoxuser;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxln;
        private System.Windows.Forms.TextBox textBoxfn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonlog;
        private System.Windows.Forms.TextBox textBoxpw;
        private System.Windows.Forms.TextBox textBoxun;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button buttonbrws;
        private System.Windows.Forms.Button buttoncrt;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lgolog;
        private System.Windows.Forms.Label lgosign;
        private System.Windows.Forms.Label labelClose;
        private System.Windows.Forms.Label labelminimize;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
    }
}