﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace GYM
{
    public partial class All_Members : Form
    {
        public All_Members()
        {
            InitializeComponent();
        }

        private void All_Members_Load(object sender, EventArgs e)
        {
            //populate datagrid view with members
            //DataGridViewImageColumn mpiccol = new DataGridViewImageColumn();

            dataGridView1.RowTemplate.Height = 50;

            MEMBERS mem = new MEMBERS();
            MySqlCommand command = new MySqlCommand("SELECT mfname as 'first name', mlname as 'last name', mbday as 'DOB', mgen as 'gender', mnic as 'NIC', mphone as 'phone', memail as 'email', maddrs as 'address', mpic as 'picture', sessions.sname as 'session' FROM members INNER JOIN sessions on members.sid = sessions.sid WHERE members.aid=@aid");
            command.Parameters.Add("@aid", MySqlDbType.Int32).Value = GLOBAL.GlobaluserId;
            dataGridView1.DataSource = mem.selectMemberList(command);

            //mpiccol = (DataGridViewImageColumn)dataGridView1.Columns[7];
            //mpiccol.ImageLayout = DataGridViewImageCellLayout.Stretch;

            for(int i = 0; i< dataGridView1.Rows.Count;i++)
            {
                if(IsOdd(i))
                {
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.Azure;
                }
            }

           //populate listbox with members name
             SESSIONS ses = new SESSIONS();
            listBox1.DataSource = ses.getSessions(GLOBAL.GlobaluserId);
            listBox1.DisplayMember = "sname";
            listBox1.ValueMember = "sid";

        }

        //close
        private void labelClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void labelClose_MouseEnter(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.White;
        }

        private void labelClose_MouseLeave(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.Orange;
        }

        private void labelminimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void labelminimize_MouseEnter(object sender, EventArgs e)
        {
            labelminimize.ForeColor = Color.White;
        }

        private void labelminimize_MouseLeave(object sender, EventArgs e)
        {
            labelminimize.ForeColor = Color.Orange;
        }
        
        
        //
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // display members in the selsected session

            try
            {
                MEMBERS mem = new MEMBERS();
                int sid = (Int32)listBox1.SelectedValue;
                MySqlCommand command = new MySqlCommand("SELECT mfname as 'first name', mlname as 'last name', mbday as 'DOB', mgen as 'gender', mnic as 'NIC', mphone as 'phone', memail as 'email', maddrs as 'address', mpic as 'picture', sessions.sname as 'session' FROM members INNER JOIN sessions on members.sid = sessions.sid WHERE members.aid=@aid AND members.sid=@sid");
                command.Parameters.Add("@aid", MySqlDbType.Int32).Value = GLOBAL.GlobaluserId;
                command.Parameters.Add("@sid", MySqlDbType.Int32).Value = sid;
                dataGridView1.DataSource = mem.selectMemberList(command);

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (IsOdd(i))
                    {
                        dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    }
                }
            }
            catch
            {

            }
        }

        //show all members in datagrid
        private void labelshowall_Click(object sender, EventArgs e)
        {
            // call th4 form load
            All_Members_Load(null, null);
        }

        //datagrid back colors
        public bool IsOdd(int value)
        {
            //return true if the value =2,4,6,8.......
            //return true if the value =1,3,5,7.......
            return value % 2 != 0;

        }

        private void dataGridView1_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                if (IsOdd(i))
                {
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                }
            }
        }
    }
}
