﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GYM
{
    class GLOBAL
    {
      //this makes the loged in user global in the whole application
      public static int GlobaluserId { get; private set; }

        public static void SetGlobaluserid(int aid)
        {
            GlobaluserId = aid;
        }
    }
}
