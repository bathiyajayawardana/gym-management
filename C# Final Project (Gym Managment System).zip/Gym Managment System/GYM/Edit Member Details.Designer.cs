﻿namespace GYM
{
    partial class Edit_Member_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelEditMEmTitle = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonSelMidEdit = new System.Windows.Forms.Button();
            this.textBoxEMid = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonMemEdit = new System.Windows.Forms.Button();
            this.buttonMemPicEdit = new System.Windows.Forms.Button();
            this.pictureBoxAddMemPicEdit = new System.Windows.Forms.PictureBox();
            this.comboBoxEMses = new System.Windows.Forms.ComboBox();
            this.labelMses = new System.Windows.Forms.Label();
            this.textBoxEMaddrs = new System.Windows.Forms.TextBox();
            this.labelMadrs = new System.Windows.Forms.Label();
            this.textBoxEMeml = new System.Windows.Forms.TextBox();
            this.labelMeml = new System.Windows.Forms.Label();
            this.textBoxEMphn = new System.Windows.Forms.TextBox();
            this.labelMphone = new System.Windows.Forms.Label();
            this.textBoxEMnic = new System.Windows.Forms.TextBox();
            this.labelMnic = new System.Windows.Forms.Label();
            this.textBoxEMgen = new System.Windows.Forms.TextBox();
            this.textBoxEMdob = new System.Windows.Forms.TextBox();
            this.labelMgender = new System.Windows.Forms.Label();
            this.labelMbday = new System.Windows.Forms.Label();
            this.textBoxEMln = new System.Windows.Forms.TextBox();
            this.textBoxEMfn = new System.Windows.Forms.TextBox();
            this.labelMlname = new System.Windows.Forms.Label();
            this.labelMfname = new System.Windows.Forms.Label();
            this.labelminimize = new System.Windows.Forms.Label();
            this.labelClose = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAddMemPicEdit)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.panel1.Controls.Add(this.labelEditMEmTitle);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.labelminimize);
            this.panel1.Controls.Add(this.labelClose);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1083, 731);
            this.panel1.TabIndex = 0;
            // 
            // labelEditMEmTitle
            // 
            this.labelEditMEmTitle.AutoSize = true;
            this.labelEditMEmTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEditMEmTitle.ForeColor = System.Drawing.Color.Black;
            this.labelEditMEmTitle.Location = new System.Drawing.Point(9, 12);
            this.labelEditMEmTitle.Name = "labelEditMEmTitle";
            this.labelEditMEmTitle.Size = new System.Drawing.Size(250, 29);
            this.labelEditMEmTitle.TabIndex = 60;
            this.labelEditMEmTitle.Text = "Edit Member Details";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.panel2.Controls.Add(this.buttonSelMidEdit);
            this.panel2.Controls.Add(this.textBoxEMid);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.buttonMemEdit);
            this.panel2.Controls.Add(this.buttonMemPicEdit);
            this.panel2.Controls.Add(this.pictureBoxAddMemPicEdit);
            this.panel2.Controls.Add(this.comboBoxEMses);
            this.panel2.Controls.Add(this.labelMses);
            this.panel2.Controls.Add(this.textBoxEMaddrs);
            this.panel2.Controls.Add(this.labelMadrs);
            this.panel2.Controls.Add(this.textBoxEMeml);
            this.panel2.Controls.Add(this.labelMeml);
            this.panel2.Controls.Add(this.textBoxEMphn);
            this.panel2.Controls.Add(this.labelMphone);
            this.panel2.Controls.Add(this.textBoxEMnic);
            this.panel2.Controls.Add(this.labelMnic);
            this.panel2.Controls.Add(this.textBoxEMgen);
            this.panel2.Controls.Add(this.textBoxEMdob);
            this.panel2.Controls.Add(this.labelMgender);
            this.panel2.Controls.Add(this.labelMbday);
            this.panel2.Controls.Add(this.textBoxEMln);
            this.panel2.Controls.Add(this.textBoxEMfn);
            this.panel2.Controls.Add(this.labelMlname);
            this.panel2.Controls.Add(this.labelMfname);
            this.panel2.Location = new System.Drawing.Point(0, 53);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1083, 695);
            this.panel2.TabIndex = 59;
            // 
            // buttonSelMidEdit
            // 
            this.buttonSelMidEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonSelMidEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSelMidEdit.Location = new System.Drawing.Point(17, 63);
            this.buttonSelMidEdit.Name = "buttonSelMidEdit";
            this.buttonSelMidEdit.Size = new System.Drawing.Size(298, 48);
            this.buttonSelMidEdit.TabIndex = 59;
            this.buttonSelMidEdit.Text = "Select";
            this.buttonSelMidEdit.UseVisualStyleBackColor = false;
            this.buttonSelMidEdit.Click += new System.EventHandler(this.buttonSelMidEdit_Click);
            // 
            // textBoxEMid
            // 
            this.textBoxEMid.BackColor = System.Drawing.Color.White;
            this.textBoxEMid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEMid.ForeColor = System.Drawing.Color.Black;
            this.textBoxEMid.Location = new System.Drawing.Point(149, 14);
            this.textBoxEMid.Name = "textBoxEMid";
            this.textBoxEMid.Size = new System.Drawing.Size(166, 35);
            this.textBoxEMid.TabIndex = 58;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 29);
            this.label1.TabIndex = 57;
            this.label1.Text = "Member ID";
            // 
            // buttonMemEdit
            // 
            this.buttonMemEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonMemEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMemEdit.Location = new System.Drawing.Point(404, 585);
            this.buttonMemEdit.Name = "buttonMemEdit";
            this.buttonMemEdit.Size = new System.Drawing.Size(613, 56);
            this.buttonMemEdit.TabIndex = 56;
            this.buttonMemEdit.Text = "Edit Member Details";
            this.buttonMemEdit.UseVisualStyleBackColor = false;
            this.buttonMemEdit.Click += new System.EventHandler(this.buttonMemEdit_Click);
            // 
            // buttonMemPicEdit
            // 
            this.buttonMemPicEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonMemPicEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMemPicEdit.Location = new System.Drawing.Point(30, 408);
            this.buttonMemPicEdit.Name = "buttonMemPicEdit";
            this.buttonMemPicEdit.Size = new System.Drawing.Size(276, 56);
            this.buttonMemPicEdit.TabIndex = 55;
            this.buttonMemPicEdit.Text = "Add Picture";
            this.buttonMemPicEdit.UseVisualStyleBackColor = false;
            this.buttonMemPicEdit.Click += new System.EventHandler(this.buttonMemPicEdit_Click);
            // 
            // pictureBoxAddMemPicEdit
            // 
            this.pictureBoxAddMemPicEdit.BackColor = System.Drawing.Color.White;
            this.pictureBoxAddMemPicEdit.Location = new System.Drawing.Point(30, 163);
            this.pictureBoxAddMemPicEdit.Name = "pictureBoxAddMemPicEdit";
            this.pictureBoxAddMemPicEdit.Size = new System.Drawing.Size(276, 227);
            this.pictureBoxAddMemPicEdit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxAddMemPicEdit.TabIndex = 54;
            this.pictureBoxAddMemPicEdit.TabStop = false;
            // 
            // comboBoxEMses
            // 
            this.comboBoxEMses.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxEMses.FormattingEnabled = true;
            this.comboBoxEMses.Location = new System.Drawing.Point(556, 527);
            this.comboBoxEMses.Name = "comboBoxEMses";
            this.comboBoxEMses.Size = new System.Drawing.Size(328, 37);
            this.comboBoxEMses.TabIndex = 53;
            // 
            // labelMses
            // 
            this.labelMses.AutoSize = true;
            this.labelMses.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMses.ForeColor = System.Drawing.Color.White;
            this.labelMses.Location = new System.Drawing.Point(396, 535);
            this.labelMses.Name = "labelMses";
            this.labelMses.Size = new System.Drawing.Size(100, 29);
            this.labelMses.TabIndex = 52;
            this.labelMses.Text = "Session";
            // 
            // textBoxEMaddrs
            // 
            this.textBoxEMaddrs.BackColor = System.Drawing.Color.White;
            this.textBoxEMaddrs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEMaddrs.ForeColor = System.Drawing.Color.Black;
            this.textBoxEMaddrs.Location = new System.Drawing.Point(557, 416);
            this.textBoxEMaddrs.Multiline = true;
            this.textBoxEMaddrs.Name = "textBoxEMaddrs";
            this.textBoxEMaddrs.Size = new System.Drawing.Size(462, 88);
            this.textBoxEMaddrs.TabIndex = 51;
            // 
            // labelMadrs
            // 
            this.labelMadrs.AutoSize = true;
            this.labelMadrs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMadrs.ForeColor = System.Drawing.Color.White;
            this.labelMadrs.Location = new System.Drawing.Point(394, 419);
            this.labelMadrs.Name = "labelMadrs";
            this.labelMadrs.Size = new System.Drawing.Size(102, 29);
            this.labelMadrs.TabIndex = 50;
            this.labelMadrs.Text = "Address";
            // 
            // textBoxEMeml
            // 
            this.textBoxEMeml.BackColor = System.Drawing.Color.White;
            this.textBoxEMeml.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEMeml.ForeColor = System.Drawing.Color.Black;
            this.textBoxEMeml.Location = new System.Drawing.Point(556, 355);
            this.textBoxEMeml.Name = "textBoxEMeml";
            this.textBoxEMeml.Size = new System.Drawing.Size(461, 35);
            this.textBoxEMeml.TabIndex = 49;
            // 
            // labelMeml
            // 
            this.labelMeml.AutoSize = true;
            this.labelMeml.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMeml.ForeColor = System.Drawing.Color.White;
            this.labelMeml.Location = new System.Drawing.Point(395, 358);
            this.labelMeml.Name = "labelMeml";
            this.labelMeml.Size = new System.Drawing.Size(74, 29);
            this.labelMeml.TabIndex = 48;
            this.labelMeml.Text = "Email";
            // 
            // textBoxEMphn
            // 
            this.textBoxEMphn.BackColor = System.Drawing.Color.White;
            this.textBoxEMphn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEMphn.ForeColor = System.Drawing.Color.Black;
            this.textBoxEMphn.Location = new System.Drawing.Point(556, 299);
            this.textBoxEMphn.Name = "textBoxEMphn";
            this.textBoxEMphn.Size = new System.Drawing.Size(461, 35);
            this.textBoxEMphn.TabIndex = 47;
            // 
            // labelMphone
            // 
            this.labelMphone.AutoSize = true;
            this.labelMphone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMphone.ForeColor = System.Drawing.Color.White;
            this.labelMphone.Location = new System.Drawing.Point(393, 302);
            this.labelMphone.Name = "labelMphone";
            this.labelMphone.Size = new System.Drawing.Size(83, 29);
            this.labelMphone.TabIndex = 46;
            this.labelMphone.Text = "Phone";
            // 
            // textBoxEMnic
            // 
            this.textBoxEMnic.BackColor = System.Drawing.Color.White;
            this.textBoxEMnic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEMnic.ForeColor = System.Drawing.Color.Black;
            this.textBoxEMnic.Location = new System.Drawing.Point(557, 242);
            this.textBoxEMnic.Name = "textBoxEMnic";
            this.textBoxEMnic.Size = new System.Drawing.Size(461, 35);
            this.textBoxEMnic.TabIndex = 45;
            // 
            // labelMnic
            // 
            this.labelMnic.AutoSize = true;
            this.labelMnic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMnic.ForeColor = System.Drawing.Color.White;
            this.labelMnic.Location = new System.Drawing.Point(399, 246);
            this.labelMnic.Name = "labelMnic";
            this.labelMnic.Size = new System.Drawing.Size(54, 29);
            this.labelMnic.TabIndex = 44;
            this.labelMnic.Text = "NIC";
            // 
            // textBoxEMgen
            // 
            this.textBoxEMgen.BackColor = System.Drawing.Color.White;
            this.textBoxEMgen.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEMgen.ForeColor = System.Drawing.Color.Black;
            this.textBoxEMgen.Location = new System.Drawing.Point(556, 180);
            this.textBoxEMgen.Name = "textBoxEMgen";
            this.textBoxEMgen.Size = new System.Drawing.Size(461, 35);
            this.textBoxEMgen.TabIndex = 43;
            // 
            // textBoxEMdob
            // 
            this.textBoxEMdob.BackColor = System.Drawing.Color.White;
            this.textBoxEMdob.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEMdob.ForeColor = System.Drawing.Color.Black;
            this.textBoxEMdob.Location = new System.Drawing.Point(556, 127);
            this.textBoxEMdob.Name = "textBoxEMdob";
            this.textBoxEMdob.Size = new System.Drawing.Size(461, 35);
            this.textBoxEMdob.TabIndex = 42;
            // 
            // labelMgender
            // 
            this.labelMgender.AutoSize = true;
            this.labelMgender.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMgender.ForeColor = System.Drawing.Color.White;
            this.labelMgender.Location = new System.Drawing.Point(396, 180);
            this.labelMgender.Name = "labelMgender";
            this.labelMgender.Size = new System.Drawing.Size(94, 29);
            this.labelMgender.TabIndex = 41;
            this.labelMgender.Text = "Gender";
            // 
            // labelMbday
            // 
            this.labelMbday.AutoSize = true;
            this.labelMbday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMbday.ForeColor = System.Drawing.Color.White;
            this.labelMbday.Location = new System.Drawing.Point(395, 124);
            this.labelMbday.Name = "labelMbday";
            this.labelMbday.Size = new System.Drawing.Size(144, 29);
            this.labelMbday.TabIndex = 40;
            this.labelMbday.Text = "Date of Birth";
            // 
            // textBoxEMln
            // 
            this.textBoxEMln.BackColor = System.Drawing.Color.White;
            this.textBoxEMln.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEMln.ForeColor = System.Drawing.Color.Black;
            this.textBoxEMln.Location = new System.Drawing.Point(556, 63);
            this.textBoxEMln.Name = "textBoxEMln";
            this.textBoxEMln.Size = new System.Drawing.Size(461, 35);
            this.textBoxEMln.TabIndex = 39;
            // 
            // textBoxEMfn
            // 
            this.textBoxEMfn.BackColor = System.Drawing.Color.White;
            this.textBoxEMfn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEMfn.ForeColor = System.Drawing.Color.Black;
            this.textBoxEMfn.Location = new System.Drawing.Point(558, 7);
            this.textBoxEMfn.Name = "textBoxEMfn";
            this.textBoxEMfn.Size = new System.Drawing.Size(461, 35);
            this.textBoxEMfn.TabIndex = 38;
            // 
            // labelMlname
            // 
            this.labelMlname.AutoSize = true;
            this.labelMlname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMlname.ForeColor = System.Drawing.Color.White;
            this.labelMlname.Location = new System.Drawing.Point(396, 63);
            this.labelMlname.Name = "labelMlname";
            this.labelMlname.Size = new System.Drawing.Size(128, 29);
            this.labelMlname.TabIndex = 37;
            this.labelMlname.Text = "Last Name";
            // 
            // labelMfname
            // 
            this.labelMfname.AutoSize = true;
            this.labelMfname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMfname.ForeColor = System.Drawing.Color.White;
            this.labelMfname.Location = new System.Drawing.Point(396, 7);
            this.labelMfname.Name = "labelMfname";
            this.labelMfname.Size = new System.Drawing.Size(131, 29);
            this.labelMfname.TabIndex = 36;
            this.labelMfname.Text = "First Name";
            // 
            // labelminimize
            // 
            this.labelminimize.AutoSize = true;
            this.labelminimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelminimize.Location = new System.Drawing.Point(1013, 9);
            this.labelminimize.Name = "labelminimize";
            this.labelminimize.Size = new System.Drawing.Size(20, 26);
            this.labelminimize.TabIndex = 58;
            this.labelminimize.Text = "-";
            this.labelminimize.Click += new System.EventHandler(this.labelminimize_Click);
            this.labelminimize.MouseEnter += new System.EventHandler(this.labelminimize_MouseEnter);
            this.labelminimize.MouseLeave += new System.EventHandler(this.labelminimize_MouseLeave);
            // 
            // labelClose
            // 
            this.labelClose.AutoSize = true;
            this.labelClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelClose.Location = new System.Drawing.Point(1039, 11);
            this.labelClose.Name = "labelClose";
            this.labelClose.Size = new System.Drawing.Size(27, 25);
            this.labelClose.TabIndex = 57;
            this.labelClose.Text = "X";
            this.labelClose.Click += new System.EventHandler(this.labelClose_Click);
            this.labelClose.MouseEnter += new System.EventHandler(this.labelClose_MouseEnter);
            this.labelClose.MouseLeave += new System.EventHandler(this.labelClose_MouseLeave);
            // 
            // Edit_Member_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1083, 731);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Edit_Member_Details";
            this.Text = "Edit_Member_Details";
            this.Load += new System.EventHandler(this.Edit_Member_Details_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAddMemPicEdit)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelminimize;
        private System.Windows.Forms.Label labelClose;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelEditMEmTitle;
        private System.Windows.Forms.Button buttonMemEdit;
        private System.Windows.Forms.Button buttonMemPicEdit;
        private System.Windows.Forms.PictureBox pictureBoxAddMemPicEdit;
        private System.Windows.Forms.ComboBox comboBoxEMses;
        private System.Windows.Forms.Label labelMses;
        private System.Windows.Forms.TextBox textBoxEMaddrs;
        private System.Windows.Forms.Label labelMadrs;
        private System.Windows.Forms.TextBox textBoxEMeml;
        private System.Windows.Forms.Label labelMeml;
        private System.Windows.Forms.TextBox textBoxEMphn;
        private System.Windows.Forms.Label labelMphone;
        private System.Windows.Forms.TextBox textBoxEMnic;
        private System.Windows.Forms.Label labelMnic;
        private System.Windows.Forms.TextBox textBoxEMgen;
        private System.Windows.Forms.TextBox textBoxEMdob;
        private System.Windows.Forms.Label labelMgender;
        private System.Windows.Forms.Label labelMbday;
        private System.Windows.Forms.TextBox textBoxEMln;
        private System.Windows.Forms.TextBox textBoxEMfn;
        private System.Windows.Forms.Label labelMlname;
        private System.Windows.Forms.Label labelMfname;
        private System.Windows.Forms.Button buttonSelMidEdit;
        private System.Windows.Forms.TextBox textBoxEMid;
        private System.Windows.Forms.Label label1;
    }
}