﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace GYM
{
    public partial class MAINFORM : Form
    {
        public MAINFORM()
        {
            InitializeComponent();
        }

        wzone wz = new wzone();
        SESSIONS ses = new SESSIONS();
        
        //close
        private void labelClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void labelClose_MouseEnter(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.White;
        }

        private void labelClose_MouseLeave(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.Black;
        }
        //minimise
        private void labelminimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void labelminimize_MouseEnter(object sender, EventArgs e)
        {
            labelminimize.ForeColor = Color.White;
        }

        private void labelminimize_MouseMove(object sender, MouseEventArgs e)
        {
            labelminimize.ForeColor = Color.Black;
        }

        //function to display the logged in image and username
        public void getImageAndUsername()
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable table = new DataTable();
            MySqlCommand command = new MySqlCommand("SELECT * FROM `gym admin` WHERE `aid`=@aid", wz.getConnection);

            command.Parameters.Add("@aid", MySqlDbType.Int32).Value= GLOBAL.GlobaluserId;
            adapter.SelectCommand = command;
            adapter.Fill(table);

            if(table.Rows.Count>0)
            {
                //display user image
                byte[] pic = (byte[])table.Rows[0]["apic"];
                MemoryStream picture = new MemoryStream(pic);
                pictureBoxglb.Image = Image.FromStream(picture);

                //dispaly the username

                labelwelcome.Text = "Welcome Back(" + table.Rows[0]["auname"] + ")";
            }
        }

        //form load
        private void MAINFORM_Load(object sender, EventArgs e)
        {
            //display the user image and username
            getImageAndUsername();

            //populate the combobox with the session name
            getSessions();
        }

        //label to edit admin information 
        private void leditinfo_Click(object sender, EventArgs e)
        {
            EDITADMIN editad = new EDITADMIN();
            editad.Show(this);
        }

        //Button to add  session
        private void buttonsadd_Click(object sender, EventArgs e)
        {
            string sname = textBoxsadd.Text;
            
            if(!sname.Trim().Equals(""))
            {
                // check if the group name already exists for the logged in user
                if(!ses.sessionExists(sname,"add",GLOBAL.GlobaluserId))
                {
                    if(ses.insertSession(sname,GLOBAL.GlobaluserId))
                    {
                        MessageBox.Show("New Session Added", "Add Session", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Session Not Added", "Add Session", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    getSessions(); //populate the combobox again to display the new data
                }
                else
                {
                    MessageBox.Show("This Session is Already Exists","Add Session", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Please Enter a Session Name", "Add Session", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //populate the combobox
        public void getSessions()
        {
            //populate edit combobox
            comboBoxseditid.DataSource = ses.getSessions(GLOBAL.GlobaluserId);
            comboBoxseditid.DisplayMember = "sname";
            comboBoxseditid.ValueMember = "sid";

            //populate remove combobox
            comboBoxRemoveSession.DataSource = ses.getSessions(GLOBAL.GlobaluserId);
            comboBoxRemoveSession.DisplayMember = "sname";
            comboBoxRemoveSession.ValueMember = "sid";
        }

        //button to edit session name
        private void buttonseditname_Click(object sender, EventArgs e)
        {
             try
             {
                string newSessionname = textBoxseditname.Text;
                int sid = Convert.ToInt32(comboBoxseditid.SelectedValue.ToString());

                if (!newSessionname.Trim().Equals(""))
                {
                    if (!ses.sessionExists(newSessionname, "Edit", GLOBAL.GlobaluserId, sid))
                    {
                        if (ses.updateSessions(sid, newSessionname))
                        {
                            MessageBox.Show("Session Name Updated", "Edit Session", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Session Name not Updated", "Edit Session", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }

                        getSessions();
                    }
                    else
                    {
                        MessageBox.Show("This Session Name is Already Exists", "Edit Session", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                   MessageBox.Show("Please Enter Session Name", "Edit Session", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
             }
             catch
             {
                 MessageBox.Show("Please Enter a Sesion Name", "Edit Session", MessageBoxButtons.OK, MessageBoxIcon.Warning);
             }

        }
            

        //button remove session
        private void buttonsremove_Click(object sender, EventArgs e)
        {
          try
          {
             int sid = Convert.ToInt32(comboBoxRemoveSession.SelectedValue.ToString());

              if (MessageBox.Show("Are You Sure You Want To Delete This Session", "Remove Session", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
              {
                    if (ses.deleteSession(sid))
                    {
                         MessageBox.Show("Session Deleted", "Remove Session", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Session Not Deleted", "Remove Session", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                    getSessions();

              }
              else
              {
                 MessageBox.Show("Please Enter Session Name", "Remove Session", MessageBoxButtons.OK, MessageBoxIcon.Warning);
              }

          }
          catch
          {
             MessageBox.Show("Please Enter Session Name", "Remove Session", MessageBoxButtons.OK, MessageBoxIcon.Warning);
          }
          
        }

        //refresh the user image and username
        private void labelRefresh_Click(object sender, EventArgs e)
        {
            getImageAndUsername();
        }


        //button to add new member
        private void buttonAddMem_Click(object sender, EventArgs e)
        {
            //show add member form
            Add_Member_Details addMem = new Add_Member_Details();
            addMem.Show(this);
        }

        //button edit member
        private void buttonEdMem_Click(object sender, EventArgs e)
        {
            Edit_Member_Details editMem = new Edit_Member_Details();
            editMem.Show(this);
        }

        //button select member
        private void buttonSelMem_Click(object sender, EventArgs e)
        {
            // show a form to select the member admin want to edit
            Select_Member selectMem = new Select_Member();
            selectMem.ShowDialog();

            try
            {
                //get the member id
                int memberId = Convert.ToInt32(selectMem.dataGridView1.CurrentRow.Cells[0].Value.ToString());

                textBoxMemId.Text = memberId.ToString();
           
            }
            catch
            {

            }
        }

        //button delete the selected member
        private void buttonRemvMem_Click(object sender, EventArgs e)
        {
            MEMBERS mem = new MEMBERS();

            try
            {
                if (!textBoxMemId.Text.Trim().Equals(""))
                {
                    int memberId = Convert.ToInt32(textBoxMemId.Text);

                    if (mem.deleteMember(memberId))
                    {
                        MessageBox.Show("Member Deleted", "Remove Member", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Error", "Remove Member", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please Select A Member ID", "Remove Member", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Remove member", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

          
        }

        //button to show all members
        private void buttonShowAllMem_Click(object sender, EventArgs e)
        {
            All_Members allmem = new All_Members();
            allmem.Show(this);
        }
    }
}
