﻿namespace GYM
{
    partial class MAINFORM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelRefresh = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.leditinfo = new System.Windows.Forms.Label();
            this.labelwelcome = new System.Windows.Forms.Label();
            this.pictureBoxglb = new System.Windows.Forms.PictureBox();
            this.labelminimize = new System.Windows.Forms.Label();
            this.labelClose = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBoxMemId = new System.Windows.Forms.TextBox();
            this.buttonSelMem = new System.Windows.Forms.Button();
            this.buttonShowAllMem = new System.Windows.Forms.Button();
            this.buttonRemvMem = new System.Windows.Forms.Button();
            this.buttonEdMem = new System.Windows.Forms.Button();
            this.buttonAddMem = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.labelmemTitle = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBoxRemoveSession = new System.Windows.Forms.ComboBox();
            this.labelsselectR = new System.Windows.Forms.Label();
            this.buttonsremove = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBoxseditid = new System.Windows.Forms.ComboBox();
            this.labelsenternew = new System.Windows.Forms.Label();
            this.buttonseditname = new System.Windows.Forms.Button();
            this.textBoxseditname = new System.Windows.Forms.TextBox();
            this.labelsselect = new System.Windows.Forms.Label();
            this.groupBoxsadd = new System.Windows.Forms.GroupBox();
            this.buttonsadd = new System.Windows.Forms.Button();
            this.labelsadd = new System.Windows.Forms.Label();
            this.textBoxsadd = new System.Windows.Forms.TextBox();
            this.labelSESSION = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxglb)).BeginInit();
            this.panel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBoxsadd.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Purple;
            this.panel1.Controls.Add(this.labelRefresh);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.leditinfo);
            this.panel1.Controls.Add(this.labelwelcome);
            this.panel1.Controls.Add(this.pictureBoxglb);
            this.panel1.Controls.Add(this.labelminimize);
            this.panel1.Controls.Add(this.labelClose);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1277, 722);
            this.panel1.TabIndex = 0;
            // 
            // labelRefresh
            // 
            this.labelRefresh.AutoSize = true;
            this.labelRefresh.Font = new System.Drawing.Font("Comic Sans MS", 8F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRefresh.ForeColor = System.Drawing.Color.White;
            this.labelRefresh.Location = new System.Drawing.Point(211, 35);
            this.labelRefresh.Name = "labelRefresh";
            this.labelRefresh.Size = new System.Drawing.Size(71, 23);
            this.labelRefresh.TabIndex = 7;
            this.labelRefresh.Text = "Refresh";
            this.labelRefresh.Click += new System.EventHandler(this.labelRefresh_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(195, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(15, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "|";
            // 
            // leditinfo
            // 
            this.leditinfo.AutoSize = true;
            this.leditinfo.Font = new System.Drawing.Font("Comic Sans MS", 8F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.leditinfo.ForeColor = System.Drawing.Color.White;
            this.leditinfo.Location = new System.Drawing.Point(92, 35);
            this.leditinfo.Name = "leditinfo";
            this.leditinfo.Size = new System.Drawing.Size(103, 23);
            this.leditinfo.TabIndex = 0;
            this.leditinfo.Text = "edit my info";
            this.leditinfo.Click += new System.EventHandler(this.leditinfo_Click);
            // 
            // labelwelcome
            // 
            this.labelwelcome.AutoSize = true;
            this.labelwelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelwelcome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.labelwelcome.Location = new System.Drawing.Point(83, 9);
            this.labelwelcome.Name = "labelwelcome";
            this.labelwelcome.Size = new System.Drawing.Size(176, 20);
            this.labelwelcome.TabIndex = 24;
            this.labelwelcome.Text = "WELCOME (username)";
            // 
            // pictureBoxglb
            // 
            this.pictureBoxglb.Location = new System.Drawing.Point(12, 4);
            this.pictureBoxglb.Name = "pictureBoxglb";
            this.pictureBoxglb.Size = new System.Drawing.Size(65, 54);
            this.pictureBoxglb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxglb.TabIndex = 0;
            this.pictureBoxglb.TabStop = false;
            // 
            // labelminimize
            // 
            this.labelminimize.AutoSize = true;
            this.labelminimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelminimize.Location = new System.Drawing.Point(1206, 19);
            this.labelminimize.Name = "labelminimize";
            this.labelminimize.Size = new System.Drawing.Size(20, 26);
            this.labelminimize.TabIndex = 23;
            this.labelminimize.Text = "-";
            this.labelminimize.Click += new System.EventHandler(this.labelminimize_Click);
            this.labelminimize.MouseEnter += new System.EventHandler(this.labelminimize_MouseEnter);
            this.labelminimize.MouseMove += new System.Windows.Forms.MouseEventHandler(this.labelminimize_MouseMove);
            // 
            // labelClose
            // 
            this.labelClose.AutoSize = true;
            this.labelClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelClose.Location = new System.Drawing.Point(1232, 20);
            this.labelClose.Name = "labelClose";
            this.labelClose.Size = new System.Drawing.Size(27, 25);
            this.labelClose.TabIndex = 22;
            this.labelClose.Text = "X";
            this.labelClose.Click += new System.EventHandler(this.labelClose_Click);
            this.labelClose.MouseEnter += new System.EventHandler(this.labelClose_MouseEnter);
            this.labelClose.MouseLeave += new System.EventHandler(this.labelClose_MouseLeave);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(49)))), ((int)(((byte)(63)))));
            this.panel2.Controls.Add(this.textBoxMemId);
            this.panel2.Controls.Add(this.buttonSelMem);
            this.panel2.Controls.Add(this.buttonShowAllMem);
            this.panel2.Controls.Add(this.buttonRemvMem);
            this.panel2.Controls.Add(this.buttonEdMem);
            this.panel2.Controls.Add(this.buttonAddMem);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.labelmemTitle);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.groupBoxsadd);
            this.panel2.Controls.Add(this.labelSESSION);
            this.panel2.Location = new System.Drawing.Point(0, 64);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1277, 658);
            this.panel2.TabIndex = 0;
            // 
            // textBoxMemId
            // 
            this.textBoxMemId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMemId.Location = new System.Drawing.Point(87, 475);
            this.textBoxMemId.Name = "textBoxMemId";
            this.textBoxMemId.Size = new System.Drawing.Size(374, 35);
            this.textBoxMemId.TabIndex = 14;
            // 
            // buttonSelMem
            // 
            this.buttonSelMem.BackColor = System.Drawing.Color.Lime;
            this.buttonSelMem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSelMem.Location = new System.Drawing.Point(87, 533);
            this.buttonSelMem.Name = "buttonSelMem";
            this.buttonSelMem.Size = new System.Drawing.Size(374, 60);
            this.buttonSelMem.TabIndex = 13;
            this.buttonSelMem.Text = "Select Members";
            this.buttonSelMem.UseVisualStyleBackColor = false;
            this.buttonSelMem.Click += new System.EventHandler(this.buttonSelMem_Click);
            // 
            // buttonShowAllMem
            // 
            this.buttonShowAllMem.BackColor = System.Drawing.Color.Magenta;
            this.buttonShowAllMem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonShowAllMem.Location = new System.Drawing.Point(87, 372);
            this.buttonShowAllMem.Name = "buttonShowAllMem";
            this.buttonShowAllMem.Size = new System.Drawing.Size(374, 60);
            this.buttonShowAllMem.TabIndex = 12;
            this.buttonShowAllMem.Text = "Show Members";
            this.buttonShowAllMem.UseVisualStyleBackColor = false;
            this.buttonShowAllMem.Click += new System.EventHandler(this.buttonShowAllMem_Click);
            // 
            // buttonRemvMem
            // 
            this.buttonRemvMem.BackColor = System.Drawing.Color.Red;
            this.buttonRemvMem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRemvMem.Location = new System.Drawing.Point(87, 274);
            this.buttonRemvMem.Name = "buttonRemvMem";
            this.buttonRemvMem.Size = new System.Drawing.Size(374, 60);
            this.buttonRemvMem.TabIndex = 11;
            this.buttonRemvMem.Text = "Remove Member";
            this.buttonRemvMem.UseVisualStyleBackColor = false;
            this.buttonRemvMem.Click += new System.EventHandler(this.buttonRemvMem_Click);
            // 
            // buttonEdMem
            // 
            this.buttonEdMem.BackColor = System.Drawing.Color.Yellow;
            this.buttonEdMem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEdMem.Location = new System.Drawing.Point(87, 175);
            this.buttonEdMem.Name = "buttonEdMem";
            this.buttonEdMem.Size = new System.Drawing.Size(374, 60);
            this.buttonEdMem.TabIndex = 10;
            this.buttonEdMem.Text = "Edit Member";
            this.buttonEdMem.UseVisualStyleBackColor = false;
            this.buttonEdMem.Click += new System.EventHandler(this.buttonEdMem_Click);
            // 
            // buttonAddMem
            // 
            this.buttonAddMem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonAddMem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddMem.Location = new System.Drawing.Point(87, 75);
            this.buttonAddMem.Name = "buttonAddMem";
            this.buttonAddMem.Size = new System.Drawing.Size(374, 60);
            this.buttonAddMem.TabIndex = 9;
            this.buttonAddMem.Text = "Add Member";
            this.buttonAddMem.UseVisualStyleBackColor = false;
            this.buttonAddMem.Click += new System.EventHandler(this.buttonAddMem_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(538, 37);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(11, 585);
            this.panel3.TabIndex = 8;
            // 
            // labelmemTitle
            // 
            this.labelmemTitle.AutoSize = true;
            this.labelmemTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmemTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.labelmemTitle.Location = new System.Drawing.Point(158, 11);
            this.labelmemTitle.Name = "labelmemTitle";
            this.labelmemTitle.Size = new System.Drawing.Size(223, 46);
            this.labelmemTitle.TabIndex = 7;
            this.labelmemTitle.Text = "MEMBERS";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboBoxRemoveSession);
            this.groupBox2.Controls.Add(this.labelsselectR);
            this.groupBox2.Controls.Add(this.buttonsremove);
            this.groupBox2.Location = new System.Drawing.Point(651, 461);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(599, 161);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            // 
            // comboBoxRemoveSession
            // 
            this.comboBoxRemoveSession.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxRemoveSession.FormattingEnabled = true;
            this.comboBoxRemoveSession.Location = new System.Drawing.Point(235, 32);
            this.comboBoxRemoveSession.Name = "comboBoxRemoveSession";
            this.comboBoxRemoveSession.Size = new System.Drawing.Size(328, 37);
            this.comboBoxRemoveSession.TabIndex = 6;
            // 
            // labelsselectR
            // 
            this.labelsselectR.AutoSize = true;
            this.labelsselectR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelsselectR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.labelsselectR.Location = new System.Drawing.Point(38, 40);
            this.labelsselectR.Name = "labelsselectR";
            this.labelsselectR.Size = new System.Drawing.Size(174, 29);
            this.labelsselectR.TabIndex = 4;
            this.labelsselectR.Text = "Select Session";
            // 
            // buttonsremove
            // 
            this.buttonsremove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonsremove.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonsremove.Location = new System.Drawing.Point(43, 93);
            this.buttonsremove.Name = "buttonsremove";
            this.buttonsremove.Size = new System.Drawing.Size(520, 49);
            this.buttonsremove.TabIndex = 3;
            this.buttonsremove.Text = "Remove";
            this.buttonsremove.UseVisualStyleBackColor = false;
            this.buttonsremove.Click += new System.EventHandler(this.buttonsremove_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBoxseditid);
            this.groupBox1.Controls.Add(this.labelsenternew);
            this.groupBox1.Controls.Add(this.buttonseditname);
            this.groupBox1.Controls.Add(this.textBoxseditname);
            this.groupBox1.Controls.Add(this.labelsselect);
            this.groupBox1.Location = new System.Drawing.Point(651, 228);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(599, 225);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // comboBoxseditid
            // 
            this.comboBoxseditid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxseditid.FormattingEnabled = true;
            this.comboBoxseditid.Location = new System.Drawing.Point(235, 44);
            this.comboBoxseditid.Name = "comboBoxseditid";
            this.comboBoxseditid.Size = new System.Drawing.Size(328, 37);
            this.comboBoxseditid.TabIndex = 5;
            // 
            // labelsenternew
            // 
            this.labelsenternew.AutoSize = true;
            this.labelsenternew.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelsenternew.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.labelsenternew.Location = new System.Drawing.Point(22, 98);
            this.labelsenternew.Name = "labelsenternew";
            this.labelsenternew.Size = new System.Drawing.Size(203, 29);
            this.labelsenternew.TabIndex = 4;
            this.labelsenternew.Text = " Enter New Name";
            // 
            // buttonseditname
            // 
            this.buttonseditname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonseditname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonseditname.Location = new System.Drawing.Point(43, 151);
            this.buttonseditname.Name = "buttonseditname";
            this.buttonseditname.Size = new System.Drawing.Size(520, 49);
            this.buttonseditname.TabIndex = 3;
            this.buttonseditname.Text = "Edit ";
            this.buttonseditname.UseVisualStyleBackColor = false;
            this.buttonseditname.Click += new System.EventHandler(this.buttonseditname_Click);
            // 
            // textBoxseditname
            // 
            this.textBoxseditname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxseditname.Location = new System.Drawing.Point(235, 95);
            this.textBoxseditname.Name = "textBoxseditname";
            this.textBoxseditname.Size = new System.Drawing.Size(328, 35);
            this.textBoxseditname.TabIndex = 2;
            // 
            // labelsselect
            // 
            this.labelsselect.AutoSize = true;
            this.labelsselect.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelsselect.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.labelsselect.Location = new System.Drawing.Point(32, 46);
            this.labelsselect.Name = "labelsselect";
            this.labelsselect.Size = new System.Drawing.Size(174, 29);
            this.labelsselect.TabIndex = 1;
            this.labelsselect.Text = "Select Session";
            // 
            // groupBoxsadd
            // 
            this.groupBoxsadd.Controls.Add(this.buttonsadd);
            this.groupBoxsadd.Controls.Add(this.labelsadd);
            this.groupBoxsadd.Controls.Add(this.textBoxsadd);
            this.groupBoxsadd.Location = new System.Drawing.Point(651, 59);
            this.groupBoxsadd.Name = "groupBoxsadd";
            this.groupBoxsadd.Size = new System.Drawing.Size(599, 161);
            this.groupBoxsadd.TabIndex = 4;
            this.groupBoxsadd.TabStop = false;
            // 
            // buttonsadd
            // 
            this.buttonsadd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.buttonsadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonsadd.Location = new System.Drawing.Point(43, 93);
            this.buttonsadd.Name = "buttonsadd";
            this.buttonsadd.Size = new System.Drawing.Size(520, 49);
            this.buttonsadd.TabIndex = 3;
            this.buttonsadd.Text = "Add";
            this.buttonsadd.UseVisualStyleBackColor = false;
            this.buttonsadd.Click += new System.EventHandler(this.buttonsadd_Click);
            // 
            // labelsadd
            // 
            this.labelsadd.AutoSize = true;
            this.labelsadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelsadd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.labelsadd.Location = new System.Drawing.Point(38, 40);
            this.labelsadd.Name = "labelsadd";
            this.labelsadd.Size = new System.Drawing.Size(177, 29);
            this.labelsadd.TabIndex = 1;
            this.labelsadd.Text = " Session Name";
            // 
            // textBoxsadd
            // 
            this.textBoxsadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxsadd.Location = new System.Drawing.Point(235, 37);
            this.textBoxsadd.Name = "textBoxsadd";
            this.textBoxsadd.Size = new System.Drawing.Size(328, 35);
            this.textBoxsadd.TabIndex = 2;
            // 
            // labelSESSION
            // 
            this.labelSESSION.AutoSize = true;
            this.labelSESSION.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSESSION.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.labelSESSION.Location = new System.Drawing.Point(844, 6);
            this.labelSESSION.Name = "labelSESSION";
            this.labelSESSION.Size = new System.Drawing.Size(198, 46);
            this.labelSESSION.TabIndex = 0;
            this.labelSESSION.Text = "SESSION";
            // 
            // MAINFORM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1277, 722);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MAINFORM";
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.MAINFORM_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxglb)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBoxsadd.ResumeLayout(false);
            this.groupBoxsadd.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelClose;
        private System.Windows.Forms.PictureBox pictureBoxglb;
        private System.Windows.Forms.Label labelminimize;
        private System.Windows.Forms.Label labelwelcome;
        private System.Windows.Forms.Label leditinfo;
        private System.Windows.Forms.GroupBox groupBoxsadd;
        private System.Windows.Forms.Button buttonsadd;
        private System.Windows.Forms.Label labelsadd;
        private System.Windows.Forms.TextBox textBoxsadd;
        private System.Windows.Forms.Label labelSESSION;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBoxseditid;
        private System.Windows.Forms.Label labelsenternew;
        private System.Windows.Forms.Button buttonseditname;
        private System.Windows.Forms.TextBox textBoxseditname;
        private System.Windows.Forms.Label labelsselect;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBoxRemoveSession;
        private System.Windows.Forms.Label labelsselectR;
        private System.Windows.Forms.Button buttonsremove;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelRefresh;
        private System.Windows.Forms.TextBox textBoxMemId;
        private System.Windows.Forms.Button buttonSelMem;
        private System.Windows.Forms.Button buttonShowAllMem;
        private System.Windows.Forms.Button buttonRemvMem;
        private System.Windows.Forms.Button buttonEdMem;
        private System.Windows.Forms.Button buttonAddMem;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label labelmemTitle;
    }
}