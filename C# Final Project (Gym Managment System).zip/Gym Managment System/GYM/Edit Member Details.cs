﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GYM
{
    public partial class Edit_Member_Details : Form
    {
        public Edit_Member_Details()
        {
            InitializeComponent();
        }

        private void Edit_Member_Details_Load(object sender, EventArgs e)
        {
            //populate combobox
            SESSIONS ses = new SESSIONS();
            comboBoxEMses.DataSource = ses.getSessions(GLOBAL.GlobaluserId);
            comboBoxEMses.DisplayMember = "sname";
            comboBoxEMses.ValueMember = "sid";
        }

        //close
        private void labelClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void labelClose_MouseEnter(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.Red;
        }

        private void labelClose_MouseLeave(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.Black;
        }


        //minimized
        private void labelminimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void labelminimize_MouseEnter(object sender, EventArgs e)
        {
            labelminimize.ForeColor = Color.Red;
        }

        private void labelminimize_MouseLeave(object sender, EventArgs e)
        {
            labelminimize.ForeColor = Color.Black;
        }

        private void buttonSelMidEdit_Click(object sender, EventArgs e)
        {
            // show a form to select the member admin want to edit
            Select_Member selectMem = new Select_Member();
            selectMem.ShowDialog();

            try
            {
                //get the member id
                int memberId = Convert.ToInt32(selectMem.dataGridView1.CurrentRow.Cells[0].Value.ToString());

                MEMBERS mem = new MEMBERS();

                DataTable table = mem.selectMemberById(memberId);

                textBoxEMid.Text = table.Rows[0]["mid"].ToString();
                textBoxEMfn.Text = table.Rows[0]["mfname"].ToString();
                textBoxEMln.Text = table.Rows[0]["mlname"].ToString();
                textBoxEMdob.Text = table.Rows[0]["mbday"].ToString();
                textBoxEMgen.Text = table.Rows[0]["mgen"].ToString();
                textBoxEMnic.Text = table.Rows[0]["mnic"].ToString();
                textBoxEMphn.Text = table.Rows[0]["mphone"].ToString();
                textBoxEMeml.Text = table.Rows[0]["memail"].ToString();
                textBoxEMaddrs.Text = table.Rows[0]["maddrs"].ToString();
                comboBoxEMses.SelectedValue = table.Rows[0]["sid"];

                byte[] mpic = (byte[])table.Rows[0]["mpic"];
                MemoryStream pic = new MemoryStream(mpic);
                pictureBoxAddMemPicEdit.Image = Image.FromStream(pic);
            }
            catch
            {

            }
          

        }


        //button edit member details
        private void buttonMemEdit_Click(object sender, EventArgs e)
        {
            MEMBERS mem = new MEMBERS();

            string mfname = textBoxEMfn.Text;
            string mlname = textBoxEMln.Text;
            string mbday = textBoxEMdob.Text;
            string mgen = textBoxEMgen.Text;
            string mnic = textBoxEMnic.Text;
            string mphone = textBoxEMphn.Text;
            string memail = textBoxEMln.Text;
            string maddrs = textBoxEMaddrs.Text;
            int aid = GLOBAL.GlobaluserId;


            try
            {
                int memberId = Convert.ToInt32(textBoxEMid.Text);

                //get session id
                int sid = (int)comboBoxEMses.SelectedValue;

                //get image 
                MemoryStream mpic = new MemoryStream();
                pictureBoxAddMemPicEdit.Image.Save(mpic, pictureBoxAddMemPicEdit.Image.RawFormat);

                if (mem.editMember(memberId,mfname,mlname,mbday,mgen,mnic,mphone,memail,maddrs,mpic,sid))
                {
                    MessageBox.Show("Member Data Updated", "Edit Member", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Error", "Edit Member", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch
            {
                MessageBox.Show("One or More Fileds Are Empty", "Edit Member", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonMemPicEdit_Click(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            opf.Filter = "Select Image (*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif";

            if (opf.ShowDialog() == DialogResult.OK)
            {
                pictureBoxAddMemPicEdit.Image = Image.FromFile(opf.FileName);
            }
        }




    }
}
