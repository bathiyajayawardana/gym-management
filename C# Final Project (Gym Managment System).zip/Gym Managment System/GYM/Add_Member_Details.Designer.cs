﻿namespace GYM
{
    partial class Add_Member_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonAddMem = new System.Windows.Forms.Button();
            this.buttonAddMemPic = new System.Windows.Forms.Button();
            this.pictureBoxAddMemPic = new System.Windows.Forms.PictureBox();
            this.comboBoxMses = new System.Windows.Forms.ComboBox();
            this.labelMses = new System.Windows.Forms.Label();
            this.textBoxMaddrs = new System.Windows.Forms.TextBox();
            this.labelMadrs = new System.Windows.Forms.Label();
            this.textBoxMeml = new System.Windows.Forms.TextBox();
            this.labelMeml = new System.Windows.Forms.Label();
            this.textBoxMphn = new System.Windows.Forms.TextBox();
            this.labelMphone = new System.Windows.Forms.Label();
            this.textBoxMnic = new System.Windows.Forms.TextBox();
            this.labelMnic = new System.Windows.Forms.Label();
            this.textBoxMgen = new System.Windows.Forms.TextBox();
            this.textBoxMdob = new System.Windows.Forms.TextBox();
            this.labelMgender = new System.Windows.Forms.Label();
            this.labelMbday = new System.Windows.Forms.Label();
            this.textBoxMln = new System.Windows.Forms.TextBox();
            this.textBoxMfn = new System.Windows.Forms.TextBox();
            this.labelMlname = new System.Windows.Forms.Label();
            this.labelMfname = new System.Windows.Forms.Label();
            this.labelminimize = new System.Windows.Forms.Label();
            this.labelClose = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAddMemPic)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumTurquoise;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.labelminimize);
            this.panel1.Controls.Add(this.labelClose);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1023, 712);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(8, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(222, 29);
            this.label1.TabIndex = 27;
            this.label1.Text = "Add New Member";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.panel2.Controls.Add(this.buttonAddMem);
            this.panel2.Controls.Add(this.buttonAddMemPic);
            this.panel2.Controls.Add(this.pictureBoxAddMemPic);
            this.panel2.Controls.Add(this.comboBoxMses);
            this.panel2.Controls.Add(this.labelMses);
            this.panel2.Controls.Add(this.textBoxMaddrs);
            this.panel2.Controls.Add(this.labelMadrs);
            this.panel2.Controls.Add(this.textBoxMeml);
            this.panel2.Controls.Add(this.labelMeml);
            this.panel2.Controls.Add(this.textBoxMphn);
            this.panel2.Controls.Add(this.labelMphone);
            this.panel2.Controls.Add(this.textBoxMnic);
            this.panel2.Controls.Add(this.labelMnic);
            this.panel2.Controls.Add(this.textBoxMgen);
            this.panel2.Controls.Add(this.textBoxMdob);
            this.panel2.Controls.Add(this.labelMgender);
            this.panel2.Controls.Add(this.labelMbday);
            this.panel2.Controls.Add(this.textBoxMln);
            this.panel2.Controls.Add(this.textBoxMfn);
            this.panel2.Controls.Add(this.labelMlname);
            this.panel2.Controls.Add(this.labelMfname);
            this.panel2.Location = new System.Drawing.Point(0, 54);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1023, 657);
            this.panel2.TabIndex = 26;
            // 
            // buttonAddMem
            // 
            this.buttonAddMem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonAddMem.Location = new System.Drawing.Point(534, 583);
            this.buttonAddMem.Name = "buttonAddMem";
            this.buttonAddMem.Size = new System.Drawing.Size(460, 56);
            this.buttonAddMem.TabIndex = 35;
            this.buttonAddMem.Text = "Add Member";
            this.buttonAddMem.UseVisualStyleBackColor = false;
            this.buttonAddMem.Click += new System.EventHandler(this.buttonAddMem_Click);
            // 
            // buttonAddMemPic
            // 
            this.buttonAddMemPic.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonAddMemPic.Location = new System.Drawing.Point(56, 255);
            this.buttonAddMemPic.Name = "buttonAddMemPic";
            this.buttonAddMemPic.Size = new System.Drawing.Size(235, 56);
            this.buttonAddMemPic.TabIndex = 34;
            this.buttonAddMemPic.Text = "Add Picture";
            this.buttonAddMemPic.UseVisualStyleBackColor = false;
            this.buttonAddMemPic.Click += new System.EventHandler(this.buttonAddMemPic_Click);
            // 
            // pictureBoxAddMemPic
            // 
            this.pictureBoxAddMemPic.BackColor = System.Drawing.Color.White;
            this.pictureBoxAddMemPic.Location = new System.Drawing.Point(41, 14);
            this.pictureBoxAddMemPic.Name = "pictureBoxAddMemPic";
            this.pictureBoxAddMemPic.Size = new System.Drawing.Size(276, 227);
            this.pictureBoxAddMemPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxAddMemPic.TabIndex = 33;
            this.pictureBoxAddMemPic.TabStop = false;
            // 
            // comboBoxMses
            // 
            this.comboBoxMses.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxMses.FormattingEnabled = true;
            this.comboBoxMses.Location = new System.Drawing.Point(533, 525);
            this.comboBoxMses.Name = "comboBoxMses";
            this.comboBoxMses.Size = new System.Drawing.Size(328, 37);
            this.comboBoxMses.TabIndex = 32;
            // 
            // labelMses
            // 
            this.labelMses.AutoSize = true;
            this.labelMses.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMses.ForeColor = System.Drawing.Color.White;
            this.labelMses.Location = new System.Drawing.Point(373, 533);
            this.labelMses.Name = "labelMses";
            this.labelMses.Size = new System.Drawing.Size(100, 29);
            this.labelMses.TabIndex = 31;
            this.labelMses.Text = "Session";
            // 
            // textBoxMaddrs
            // 
            this.textBoxMaddrs.BackColor = System.Drawing.Color.White;
            this.textBoxMaddrs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMaddrs.ForeColor = System.Drawing.Color.Black;
            this.textBoxMaddrs.Location = new System.Drawing.Point(534, 414);
            this.textBoxMaddrs.Multiline = true;
            this.textBoxMaddrs.Name = "textBoxMaddrs";
            this.textBoxMaddrs.Size = new System.Drawing.Size(462, 88);
            this.textBoxMaddrs.TabIndex = 30;
            // 
            // labelMadrs
            // 
            this.labelMadrs.AutoSize = true;
            this.labelMadrs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMadrs.ForeColor = System.Drawing.Color.White;
            this.labelMadrs.Location = new System.Drawing.Point(371, 417);
            this.labelMadrs.Name = "labelMadrs";
            this.labelMadrs.Size = new System.Drawing.Size(102, 29);
            this.labelMadrs.TabIndex = 29;
            this.labelMadrs.Text = "Address";
            // 
            // textBoxMeml
            // 
            this.textBoxMeml.BackColor = System.Drawing.Color.White;
            this.textBoxMeml.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMeml.ForeColor = System.Drawing.Color.Black;
            this.textBoxMeml.Location = new System.Drawing.Point(533, 353);
            this.textBoxMeml.Name = "textBoxMeml";
            this.textBoxMeml.Size = new System.Drawing.Size(461, 35);
            this.textBoxMeml.TabIndex = 28;
            // 
            // labelMeml
            // 
            this.labelMeml.AutoSize = true;
            this.labelMeml.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMeml.ForeColor = System.Drawing.Color.White;
            this.labelMeml.Location = new System.Drawing.Point(372, 356);
            this.labelMeml.Name = "labelMeml";
            this.labelMeml.Size = new System.Drawing.Size(74, 29);
            this.labelMeml.TabIndex = 27;
            this.labelMeml.Text = "Email";
            // 
            // textBoxMphn
            // 
            this.textBoxMphn.BackColor = System.Drawing.Color.White;
            this.textBoxMphn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMphn.ForeColor = System.Drawing.Color.Black;
            this.textBoxMphn.Location = new System.Drawing.Point(533, 297);
            this.textBoxMphn.Name = "textBoxMphn";
            this.textBoxMphn.Size = new System.Drawing.Size(461, 35);
            this.textBoxMphn.TabIndex = 26;
            // 
            // labelMphone
            // 
            this.labelMphone.AutoSize = true;
            this.labelMphone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMphone.ForeColor = System.Drawing.Color.White;
            this.labelMphone.Location = new System.Drawing.Point(370, 300);
            this.labelMphone.Name = "labelMphone";
            this.labelMphone.Size = new System.Drawing.Size(83, 29);
            this.labelMphone.TabIndex = 25;
            this.labelMphone.Text = "Phone";
            // 
            // textBoxMnic
            // 
            this.textBoxMnic.BackColor = System.Drawing.Color.White;
            this.textBoxMnic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMnic.ForeColor = System.Drawing.Color.Black;
            this.textBoxMnic.Location = new System.Drawing.Point(534, 240);
            this.textBoxMnic.Name = "textBoxMnic";
            this.textBoxMnic.Size = new System.Drawing.Size(461, 35);
            this.textBoxMnic.TabIndex = 24;
            // 
            // labelMnic
            // 
            this.labelMnic.AutoSize = true;
            this.labelMnic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMnic.ForeColor = System.Drawing.Color.White;
            this.labelMnic.Location = new System.Drawing.Point(376, 244);
            this.labelMnic.Name = "labelMnic";
            this.labelMnic.Size = new System.Drawing.Size(54, 29);
            this.labelMnic.TabIndex = 23;
            this.labelMnic.Text = "NIC";
            // 
            // textBoxMgen
            // 
            this.textBoxMgen.BackColor = System.Drawing.Color.White;
            this.textBoxMgen.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMgen.ForeColor = System.Drawing.Color.Black;
            this.textBoxMgen.Location = new System.Drawing.Point(533, 178);
            this.textBoxMgen.Name = "textBoxMgen";
            this.textBoxMgen.Size = new System.Drawing.Size(461, 35);
            this.textBoxMgen.TabIndex = 22;
            // 
            // textBoxMdob
            // 
            this.textBoxMdob.BackColor = System.Drawing.Color.White;
            this.textBoxMdob.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMdob.ForeColor = System.Drawing.Color.Black;
            this.textBoxMdob.Location = new System.Drawing.Point(533, 125);
            this.textBoxMdob.Name = "textBoxMdob";
            this.textBoxMdob.Size = new System.Drawing.Size(461, 35);
            this.textBoxMdob.TabIndex = 21;
            // 
            // labelMgender
            // 
            this.labelMgender.AutoSize = true;
            this.labelMgender.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMgender.ForeColor = System.Drawing.Color.White;
            this.labelMgender.Location = new System.Drawing.Point(373, 178);
            this.labelMgender.Name = "labelMgender";
            this.labelMgender.Size = new System.Drawing.Size(94, 29);
            this.labelMgender.TabIndex = 20;
            this.labelMgender.Text = "Gender";
            // 
            // labelMbday
            // 
            this.labelMbday.AutoSize = true;
            this.labelMbday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMbday.ForeColor = System.Drawing.Color.White;
            this.labelMbday.Location = new System.Drawing.Point(372, 122);
            this.labelMbday.Name = "labelMbday";
            this.labelMbday.Size = new System.Drawing.Size(144, 29);
            this.labelMbday.TabIndex = 19;
            this.labelMbday.Text = "Date of Birth";
            // 
            // textBoxMln
            // 
            this.textBoxMln.BackColor = System.Drawing.Color.White;
            this.textBoxMln.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMln.ForeColor = System.Drawing.Color.Black;
            this.textBoxMln.Location = new System.Drawing.Point(536, 61);
            this.textBoxMln.Name = "textBoxMln";
            this.textBoxMln.Size = new System.Drawing.Size(461, 35);
            this.textBoxMln.TabIndex = 18;
            // 
            // textBoxMfn
            // 
            this.textBoxMfn.BackColor = System.Drawing.Color.White;
            this.textBoxMfn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMfn.ForeColor = System.Drawing.Color.Black;
            this.textBoxMfn.Location = new System.Drawing.Point(535, 5);
            this.textBoxMfn.Name = "textBoxMfn";
            this.textBoxMfn.Size = new System.Drawing.Size(461, 35);
            this.textBoxMfn.TabIndex = 17;
            // 
            // labelMlname
            // 
            this.labelMlname.AutoSize = true;
            this.labelMlname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMlname.ForeColor = System.Drawing.Color.White;
            this.labelMlname.Location = new System.Drawing.Point(373, 61);
            this.labelMlname.Name = "labelMlname";
            this.labelMlname.Size = new System.Drawing.Size(128, 29);
            this.labelMlname.TabIndex = 16;
            this.labelMlname.Text = "Last Name";
            // 
            // labelMfname
            // 
            this.labelMfname.AutoSize = true;
            this.labelMfname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMfname.ForeColor = System.Drawing.Color.White;
            this.labelMfname.Location = new System.Drawing.Point(373, 5);
            this.labelMfname.Name = "labelMfname";
            this.labelMfname.Size = new System.Drawing.Size(131, 29);
            this.labelMfname.TabIndex = 15;
            this.labelMfname.Text = "First Name";
            // 
            // labelminimize
            // 
            this.labelminimize.AutoSize = true;
            this.labelminimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelminimize.Location = new System.Drawing.Point(958, 11);
            this.labelminimize.Name = "labelminimize";
            this.labelminimize.Size = new System.Drawing.Size(20, 26);
            this.labelminimize.TabIndex = 25;
            this.labelminimize.Text = "-";
            this.labelminimize.Click += new System.EventHandler(this.labelminimize_Click);
            this.labelminimize.MouseEnter += new System.EventHandler(this.labelminimize_MouseEnter);
            this.labelminimize.MouseLeave += new System.EventHandler(this.labelminimize_MouseLeave);
            // 
            // labelClose
            // 
            this.labelClose.AutoSize = true;
            this.labelClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelClose.Location = new System.Drawing.Point(984, 11);
            this.labelClose.Name = "labelClose";
            this.labelClose.Size = new System.Drawing.Size(27, 25);
            this.labelClose.TabIndex = 24;
            this.labelClose.Text = "X";
            this.labelClose.Click += new System.EventHandler(this.labelClose_Click);
            this.labelClose.MouseEnter += new System.EventHandler(this.labelClose_MouseEnter);
            this.labelClose.MouseLeave += new System.EventHandler(this.labelClose_MouseLeave);
            // 
            // Add_Member_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1023, 712);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Add_Member_Details";
            this.Text = "Add_Member_Details";
            this.Load += new System.EventHandler(this.Add_Member_Details_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAddMemPic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelminimize;
        private System.Windows.Forms.Label labelClose;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBoxMgen;
        private System.Windows.Forms.TextBox textBoxMdob;
        private System.Windows.Forms.Label labelMgender;
        private System.Windows.Forms.Label labelMbday;
        private System.Windows.Forms.TextBox textBoxMln;
        private System.Windows.Forms.TextBox textBoxMfn;
        private System.Windows.Forms.Label labelMlname;
        private System.Windows.Forms.Label labelMfname;
        private System.Windows.Forms.TextBox textBoxMaddrs;
        private System.Windows.Forms.Label labelMadrs;
        private System.Windows.Forms.TextBox textBoxMeml;
        private System.Windows.Forms.Label labelMeml;
        private System.Windows.Forms.TextBox textBoxMphn;
        private System.Windows.Forms.Label labelMphone;
        private System.Windows.Forms.TextBox textBoxMnic;
        private System.Windows.Forms.Label labelMnic;
        private System.Windows.Forms.Label labelMses;
        private System.Windows.Forms.Button buttonAddMem;
        private System.Windows.Forms.Button buttonAddMemPic;
        private System.Windows.Forms.PictureBox pictureBoxAddMemPic;
        private System.Windows.Forms.ComboBox comboBoxMses;
        private System.Windows.Forms.Label label1;
    }
}