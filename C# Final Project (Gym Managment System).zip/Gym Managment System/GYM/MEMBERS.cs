﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using MySql.Data.MySqlClient;

namespace GYM
{
    class MEMBERS
    {
        wzone wz = new wzone();

        //add new member
        public bool insertMember(string mfname, string mlname, string mbday, string mgen, string mnic, string mphone, string memail, string maddrs, MemoryStream mpic, int sid, int aid)
        {
            
            MySqlCommand command = new MySqlCommand("INSERT INTO `members`(`mfname`, `mlname`, `mbday`, `mgen`, `mnic`, `mphone`, `memail`, `maddrs`, `mpic`, `sid`, `aid`) VALUES (@mfn,@mln,@mbday,@mgen,@mnic,@mphone,@memail,@maddrs,@mpic,@sid,@aid)", wz.getConnection);

            //@mfn,@mln,@mbday,@mgen,@mnic,@mphone,@memail,@maddrs,@mpic,@sid,@aid
            command.Parameters.Add("@mfn", MySqlDbType.VarChar).Value = mfname;
            command.Parameters.Add("@mln", MySqlDbType.VarChar).Value = mlname;
            command.Parameters.Add("@mbday", MySqlDbType.VarChar).Value = mbday;
            command.Parameters.Add("@mgen", MySqlDbType.VarChar).Value = mgen;
            command.Parameters.Add("@mnic", MySqlDbType.VarChar).Value = mnic;
            command.Parameters.Add("@mphone", MySqlDbType.VarChar).Value = mphone;
            command.Parameters.Add("@memail", MySqlDbType.VarChar).Value = memail;
            command.Parameters.Add("@maddrs", MySqlDbType.VarChar).Value = maddrs;
            command.Parameters.Add("@mpic", MySqlDbType.Blob).Value = mpic.ToArray();
            command.Parameters.Add("@sid", MySqlDbType.Int32).Value = sid;
            command.Parameters.Add("@aid", MySqlDbType.Int32).Value = aid;

            wz.openConnection();
             
            if (command.ExecuteNonQuery() == 1)
            {
                wz.closeConnection();
                return true;
            }
            else
            {
                wz.closeConnection();
                return false;
            }
        }


        //edit member details
        public bool editMember(int mid, string mfname, string mlname, string mbday, string mgen, string mnic, string mphone, string memail, string maddrs, MemoryStream mpic, int sid)
        {

            MySqlCommand command = new MySqlCommand("UPDATE `members` SET `mfname`=@mfn,`mlname`=@mln,`mbday`=@mbday,`mgen`=@mgen,`mnic`=@mnic,`mphone`=@mphone,`memail`=@memail,`maddrs`=@maddrs,`mpic`=@mpic,`sid`=@sid  WHERE `mid`=@mid", wz.getConnection);

            ////@mfn,@mln,@mbday,@mgen,@mnic,@mphone,@memail,@maddrs,@mpic,@sid,@mid
            // admin id is already set to the contact
            //admin can't set a contact to another admin id 

            command.Parameters.Add("@mfn", MySqlDbType.VarChar).Value = mfname;
            command.Parameters.Add("@mln", MySqlDbType.VarChar).Value = mlname;
            command.Parameters.Add("@mbday", MySqlDbType.VarChar).Value = mbday;
            command.Parameters.Add("@mgen", MySqlDbType.VarChar).Value = mgen;
            command.Parameters.Add("@mnic", MySqlDbType.VarChar).Value = mnic;
            command.Parameters.Add("@mphone", MySqlDbType.VarChar).Value = mphone;
            command.Parameters.Add("@memail", MySqlDbType.VarChar).Value = memail;
            command.Parameters.Add("@maddrs", MySqlDbType.VarChar).Value = maddrs;
            command.Parameters.Add("@mpic", MySqlDbType.Blob).Value = mpic.ToArray();
            command.Parameters.Add("@sid", MySqlDbType.Int32).Value = sid;
            command.Parameters.Add("@mid", MySqlDbType.Int32).Value = mid;

            wz.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                wz.closeConnection();
                return true;
            }
            else
            {
                wz.closeConnection();
                return false;
            }
        }


        //fuction to return a list of members depending on the given comman
        public DataTable selectMemberList(MySqlCommand command)
        {
            command.Connection = wz.getConnection;
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

        //function to get members by id
        public DataTable selectMemberById(int memberId)
        {
            MySqlCommand command = new MySqlCommand("SELECT `mid`, `mfname`, `mlname`, `mbday`, `mgen`, `mnic`, `mphone`, `memail`, `maddrs`, `mpic`, `sid`, `aid` FROM `members` WHERE `mid`=@mid", wz.getConnection);
            command.Parameters.Add("@mid", MySqlDbType.Int32).Value = memberId;
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }


        //function to delete member by id
        public bool deleteMember(int memberId)
        {
            MySqlCommand command = new MySqlCommand("DELETE FROM `members` WHERE `mid`=@mid", wz.getConnection);

            command.Parameters.Add("@mid", MySqlDbType.Int32).Value = memberId;

            wz.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                wz.closeConnection();
                return true;
            }
            else
            {
                wz.closeConnection();
                return false;
            }
        }
    }

}
