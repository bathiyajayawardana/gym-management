﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GYM
{
    public partial class LOGIN : Form
    {
        public LOGIN()
        {
            InitializeComponent();
        }

        //function for check empty fileds
        public bool verifFields(string operation)

        {
            bool check = false;

            //if opretion is register
            if (operation == "register")
            {
                if (textBoxuser.Text.Trim().Equals("") || textBoxpass.Text.Trim().Equals("") || pictureBoxadmin.Image.Equals(""))
                {
                    check = false;
                }

                else
                {
                    check = true;
                }
            }
            //if operation is login
            else if (operation == "login")
            {
                if (textBoxun.Text.Trim().Equals("") || textBoxpw.Text.Trim().Equals(""))
                {
                    check = false;
                }
                else
                {
                    check = true; ;
                }
            }

            return check;
        }


        //admin login
        private void buttonlog_Click(object sender, EventArgs e)
        {
            wzone wz = new wzone();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            DataTable table = new DataTable();

            MySqlCommand command = new MySqlCommand("SELECT * FROM `gym admin` WHERE `auname`=@aun AND `apword`=@apw",wz.getConnection);

            command.Parameters.Add("@aun", MySqlDbType.VarChar).Value = textBoxun.Text;
            command.Parameters.Add("@apw", MySqlDbType.Int32).Value = textBoxpw.Text;

            adapter.SelectCommand = command;
            adapter.Fill(table);

            //if(verifFields("login"))//check empty fields
           // {
                if (table.Rows.Count > 0)
                {
                    int aid = Convert.ToInt32(table.Rows[0][0].ToString());
                    GLOBAL.SetGlobaluserid(aid);
                    //show the main form
                    this.DialogResult = DialogResult.OK;
                    MessageBox.Show("login Succesfull", "login ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Invalid username or Password", "login error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
           
        }  
            
       
        //admin account create
        private void buttoncrt_Click(object sender, EventArgs e)
        {
            string afname = textBoxfn.Text;
            string alname = textBoxln.Text;
            string auname = textBoxuser.Text;
            string apword = textBoxpass.Text;

            NEWADMIN newad = new NEWADMIN();

            if (verifFields("register"))
            {
                MemoryStream pic = new MemoryStream();
                pictureBoxadmin.Image.Save(pic, pictureBoxadmin.Image.RawFormat);

                if (!newad.AdminExsist(auname,"register"))//check if the admin username already exixst
                {

                    if (newad.insertadmin(afname, alname, auname, apword, pic))
                    {
                        MessageBox.Show("Account Created Successfully ", "Account", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Somthin Went Wrong ", "Account", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("This uername is used,Try New Username ", "Invalid Username", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("*Required Fileds-Username/Password/Image", "register");
            }
        }


            //admin picture browsing
            private void buttonbrws_Click(object sender, EventArgs e)
            {
                OpenFileDialog opf = new OpenFileDialog();
                opf.Filter = "Select Image (*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif";

                if (opf.ShowDialog() == DialogResult.OK)
                {
                    pictureBoxadmin.Image = Image.FromFile(opf.FileName);
                }
            }

            // label for create new account
            private void lgosign_Click(object sender, EventArgs e)
            {
                timer1.Start();
                lgosign.Enabled = false;
                lgolog.Enabled = false;
            }

            //label for login 
            private void lgolog_Click(object sender, EventArgs e)
            {
                timer2.Start();
                lgolog.Enabled = false;
                lgosign.Enabled = false;
            }

            private void labelClose_MouseEnter(object sender, EventArgs e)
            {
                labelClose.ForeColor = Color.Red;
            }

            private void labelClose_MouseLeave(object sender, EventArgs e)
            {
                labelClose.ForeColor = Color.Black;
            }

            private void labelminimize_MouseEnter(object sender, EventArgs e)
            {
                labelminimize.ForeColor = Color.Red;
            }

            private void labelminimize_MouseLeave(object sender, EventArgs e)
            {
                labelminimize.ForeColor = Color.Black;
            }

            private void labelClose_Click(object sender, EventArgs e)
            {
                Close();
            }

            private void labelminimize_Click(object sender, EventArgs e)
            {
                WindowState = FormWindowState.Minimized;
            }

            //shows only regester panel
            private void timer1_Tick(object sender, EventArgs e)

            {
                if (panel2.Location.X > -290)
                {
                    panel2.Location = new Point(panel2.Location.X - 10, panel2.Location.Y);
                }
                else
                {
                    timer1.Stop();
                    lgolog.Enabled = true;
                    lgosign.Enabled = true;
                }
            }

            //shows only login panel
            private void timer2_Tick(object sender, EventArgs e)
            {
                if (panel2.Location.X < -0)
                {
                    panel2.Location = new Point(panel2.Location.X + 10, panel2.Location.Y);
                }
                else
                {
                    timer2.Stop();
                    lgolog.Enabled = true;
                    lgosign.Enabled = true;
                }
            }

        private void textBoxun_TextChanged(object sender, EventArgs e)
        {
            if(textBoxun.Text == "")
            {
                buttonlog.Enabled = false;
            }
            else
            {
                buttonlog.Enabled = true;
            }
        }

        private void textBoxpw_TextChanged(object sender, EventArgs e)
        {
            if (textBoxpw.Text == "")
            {
                buttonlog.Enabled = false;
            }
            else
            {
                buttonlog.Enabled = true;
            }
        }
    }

    }







            
