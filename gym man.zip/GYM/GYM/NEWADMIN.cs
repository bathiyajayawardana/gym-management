﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace GYM
{
    class NEWADMIN
    {
        wzone wz = new wzone();

        //fuction to check the username
       public bool AdminExsist(string auname,string operation,int aid=0)
       {
            string query = "";
           // MySqlCommand command = new MySqlCommand(query, wz.getConnection);

            if (operation == "register")
            {
                //if a new user want toregister we will check if the username already exists
                query = "SELECT * FROM `gym admin` WHERE `auname`=@aun";
                
            }
            else if(operation == "Edit")
            {
                // check if the user enter a username that already exists and it's not his
                query = "SELECT * FROM `gym admin` WHERE `auname`=@aun AND aid<> @aid";              
            }
             
            MySqlCommand command = new MySqlCommand(query, wz.getConnection);

            command.Parameters.Add("@aun", MySqlDbType.VarChar).Value = auname;
            command.Parameters.Add("@aid", MySqlDbType.Int32).Value = aid;

            MySqlDataAdapter adapter = new MySqlDataAdapter(command);

            DataTable table = new DataTable();

            adapter.Fill(table);
            //if the user exists return true
            if (table.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

       }


        //add new admin
        public bool insertadmin(string afname, string alname, string auname, string apword, MemoryStream pic)
        {
            MySqlCommand command = new MySqlCommand("INSERT INTO `gym admin`(`afname`, `alname`, `auname`, `apword`, `apic`) VALUES (@afn,@aln,@aun,@apw,@apic)", wz.getConnection);

            command.Parameters.Add("@afn", MySqlDbType.VarChar).Value = afname;
            command.Parameters.Add("@aln", MySqlDbType.VarChar).Value = alname;
            command.Parameters.Add("@aun", MySqlDbType.VarChar).Value = auname;
            command.Parameters.Add("@apw", MySqlDbType.VarChar).Value = apword;
            command.Parameters.Add("@apic", MySqlDbType.Blob).Value = pic.ToArray();

            wz.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                wz.closeConnection();
                return true;
            }
            else
            {
                wz.closeConnection();
                return false;
            }
        }

           
          //fuction to return the user data using id
        public DataTable getUserById(Int32 aid)
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable table = new DataTable();

            MySqlCommand command = new MySqlCommand("SELECT * FROM `gym admin` WHERE `aid` =@aid ",wz.getConnection);

            command.Parameters.Add("@aid", MySqlDbType.Int32).Value = aid;

            adapter.SelectCommand = command;

            adapter.Fill(table);

            return table;
        }


        //create a function to edit the user data
        public bool updateAdmin(int aid,string afname, string alname, string auname, string apword, MemoryStream pic)
        {
            MySqlCommand command = new MySqlCommand("UPDATE `gym admin` SET `afname`=@afn,`alname`=@aln,`auname`=@aun,`apword`=@apw,`apic`=@apic WHERE `aid`=@aid", wz.getConnection);

            command.Parameters.Add("@afn", MySqlDbType.VarChar).Value = afname;
            command.Parameters.Add("@aln", MySqlDbType.VarChar).Value = alname;
            command.Parameters.Add("@aun", MySqlDbType.VarChar).Value = auname;
            command.Parameters.Add("@apw", MySqlDbType.VarChar).Value = apword;
            command.Parameters.Add("@apic", MySqlDbType.Blob).Value = pic.ToArray();
            command.Parameters.Add("@aid", MySqlDbType.Int32).Value = aid;

            wz.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                wz.closeConnection();
                return true;
            }
            else
            {
                wz.closeConnection();
                return false;
            }
        }
     


      
       

        
        

    }
}
