﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GYM
{
    public partial class EDITADMIN : Form
    {
        public EDITADMIN()
        {
            InitializeComponent();
        }

        NEWADMIN nad = new NEWADMIN();

        private void EDITADMIN_Load(object sender, EventArgs e)
        {
            //diplay user data
            DataTable table = nad.getUserById(GLOBAL.GlobaluserId);
            textBoxEfname.Text = table.Rows[0][1].ToString();
            textBoxElname.Text = table.Rows[0][2].ToString();
            textBoxEuname.Text = table.Rows[0][3].ToString();
            textBoxEpword.Text = table.Rows[0][4].ToString();

            byte[] pic = (byte[])table.Rows[0]["apic"];
            MemoryStream picture = new MemoryStream(pic);
            pictureboxEpic.Image = Image.FromStream(picture);

        }

        private void labelClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void labelClose_MouseEnter(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.White;
        }

        private void labelClose_MouseLeave(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.Black;
        }

        private void labelminimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void labelminimize_MouseEnter(object sender, EventArgs e)
        {
            labelminimize.ForeColor = Color.White;
        }

        private void labelminimize_MouseLeave(object sender, EventArgs e)
        {
            labelminimize.ForeColor = Color.Black;
        }

        //browse new picture
        private void button3_Click(object sender, EventArgs e)
        {

            OpenFileDialog opf = new OpenFileDialog();
            opf.Filter = "Select Image (*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif";

            if (opf.ShowDialog() == DialogResult.OK)
            {
                pictureboxEpic.Image = Image.FromFile(opf.FileName);
            }
        }

        //button to edit admin data
        private void buttonEditad_Click(object sender, EventArgs e)
        {
            wzone wz = new wzone();

            int aid = GLOBAL.GlobaluserId;     //get the logged in user id
            string afname = textBoxEfname.Text;
            string alname = textBoxElname.Text;
            string auname = textBoxEuname.Text;
            string apword = textBoxEpword.Text;

            MemoryStream pic = new MemoryStream();
            pictureboxEpic.Image.Save(pic, pictureboxEpic.Image.RawFormat);


             if (afname.Trim().Equals("") || apword.Trim().Equals(""))  //check empty fields
             {
               MessageBox.Show("Required Fields: Username and Password", "Edit Info", MessageBoxButtons.OK, MessageBoxIcon.Error);
             }
             else
             {
                if(nad.AdminExsist(auname,"Edit",aid))
                {
                    MessageBox.Show("This uername is used,Try New Username ", "Invalid Username", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (nad.updateAdmin(aid,afname,alname,auname,apword,pic))
                {
                    MessageBox.Show("Your Information Has Been Updated", "Edit Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }               
                else
                {
                    MessageBox.Show("Error", "Edit Info", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
             }
            


        }
    }
}
