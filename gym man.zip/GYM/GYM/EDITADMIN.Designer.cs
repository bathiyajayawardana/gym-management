﻿namespace GYM
{
    partial class EDITADMIN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBoxedit = new System.Windows.Forms.PictureBox();
            this.buttoneditpic = new System.Windows.Forms.Button();
            this.labelepw = new System.Windows.Forms.Label();
            this.labelel = new System.Windows.Forms.Label();
            this.labelef = new System.Windows.Forms.Label();
            this.labeleu = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.buttonEditad = new System.Windows.Forms.Button();
            this.textBoxEpword = new System.Windows.Forms.TextBox();
            this.textBoxEuname = new System.Windows.Forms.TextBox();
            this.textBoxElname = new System.Windows.Forms.TextBox();
            this.textBoxEfname = new System.Windows.Forms.TextBox();
            this.pictureboxEpic = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelClose = new System.Windows.Forms.Label();
            this.labelminimize = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxedit)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureboxEpic)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Purple;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(950, 449);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Olive;
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.textBox4);
            this.panel2.Controls.Add(this.textBox3);
            this.panel2.Controls.Add(this.textBox2);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.pictureBoxedit);
            this.panel2.Controls.Add(this.buttoneditpic);
            this.panel2.Controls.Add(this.labelepw);
            this.panel2.Controls.Add(this.labelel);
            this.panel2.Controls.Add(this.labelef);
            this.panel2.Controls.Add(this.labeleu);
            this.panel2.Location = new System.Drawing.Point(0, 64);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(950, 426);
            this.panel2.TabIndex = 6;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(400, 298);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(513, 47);
            this.button1.TabIndex = 12;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.White;
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.ForeColor = System.Drawing.Color.Black;
            this.textBox4.Location = new System.Drawing.Point(553, 240);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(360, 32);
            this.textBox4.TabIndex = 10;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.White;
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.Color.Black;
            this.textBox3.Location = new System.Drawing.Point(553, 178);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(360, 32);
            this.textBox3.TabIndex = 9;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.Black;
            this.textBox2.Location = new System.Drawing.Point(553, 119);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(360, 32);
            this.textBox2.TabIndex = 8;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.Black;
            this.textBox1.Location = new System.Drawing.Point(553, 66);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(360, 32);
            this.textBox1.TabIndex = 7;
            // 
            // pictureBoxedit
            // 
            this.pictureBoxedit.Location = new System.Drawing.Point(35, 61);
            this.pictureBoxedit.Name = "pictureBoxedit";
            this.pictureBoxedit.Size = new System.Drawing.Size(235, 208);
            this.pictureBoxedit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxedit.TabIndex = 0;
            this.pictureBoxedit.TabStop = false;
            // 
            // buttoneditpic
            // 
            this.buttoneditpic.Location = new System.Drawing.Point(35, 298);
            this.buttoneditpic.Name = "buttoneditpic";
            this.buttoneditpic.Size = new System.Drawing.Size(235, 47);
            this.buttoneditpic.TabIndex = 1;
            this.buttoneditpic.Text = "Change Picture";
            this.buttoneditpic.UseVisualStyleBackColor = true;
            // 
            // labelepw
            // 
            this.labelepw.AutoSize = true;
            this.labelepw.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelepw.ForeColor = System.Drawing.Color.Black;
            this.labelepw.Location = new System.Drawing.Point(411, 240);
            this.labelepw.Name = "labelepw";
            this.labelepw.Size = new System.Drawing.Size(126, 29);
            this.labelepw.TabIndex = 5;
            this.labelepw.Text = "Password:";
            // 
            // labelel
            // 
            this.labelel.AutoSize = true;
            this.labelel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelel.ForeColor = System.Drawing.Color.Black;
            this.labelel.Location = new System.Drawing.Point(401, 119);
            this.labelel.Name = "labelel";
            this.labelel.Size = new System.Drawing.Size(134, 29);
            this.labelel.TabIndex = 4;
            this.labelel.Text = "Last Name:";
            // 
            // labelef
            // 
            this.labelef.AutoSize = true;
            this.labelef.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelef.ForeColor = System.Drawing.Color.Black;
            this.labelef.Location = new System.Drawing.Point(397, 64);
            this.labelef.Name = "labelef";
            this.labelef.Size = new System.Drawing.Size(137, 29);
            this.labelef.TabIndex = 2;
            this.labelef.Text = "First Name:";
            // 
            // labeleu
            // 
            this.labeleu.AutoSize = true;
            this.labeleu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeleu.ForeColor = System.Drawing.Color.Black;
            this.labeleu.Location = new System.Drawing.Point(395, 181);
            this.labeleu.Name = "labeleu";
            this.labeleu.Size = new System.Drawing.Size(141, 29);
            this.labeleu.TabIndex = 3;
            this.labeleu.Text = "User Name:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Purple;
            this.panel3.Controls.Add(this.labelminimize);
            this.panel3.Controls.Add(this.labelClose);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(950, 449);
            this.panel3.TabIndex = 7;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Olive;
            this.panel4.Controls.Add(this.buttonEditad);
            this.panel4.Controls.Add(this.textBoxEpword);
            this.panel4.Controls.Add(this.textBoxEuname);
            this.panel4.Controls.Add(this.textBoxElname);
            this.panel4.Controls.Add(this.textBoxEfname);
            this.panel4.Controls.Add(this.pictureboxEpic);
            this.panel4.Controls.Add(this.button3);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Location = new System.Drawing.Point(0, 64);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(950, 426);
            this.panel4.TabIndex = 6;
            // 
            // buttonEditad
            // 
            this.buttonEditad.Location = new System.Drawing.Point(400, 298);
            this.buttonEditad.Name = "buttonEditad";
            this.buttonEditad.Size = new System.Drawing.Size(513, 47);
            this.buttonEditad.TabIndex = 12;
            this.buttonEditad.Text = "Edit";
            this.buttonEditad.UseVisualStyleBackColor = true;
            this.buttonEditad.Click += new System.EventHandler(this.buttonEditad_Click);
            // 
            // textBoxEpword
            // 
            this.textBoxEpword.BackColor = System.Drawing.Color.White;
            this.textBoxEpword.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEpword.ForeColor = System.Drawing.Color.Black;
            this.textBoxEpword.Location = new System.Drawing.Point(553, 240);
            this.textBoxEpword.Name = "textBoxEpword";
            this.textBoxEpword.Size = new System.Drawing.Size(360, 32);
            this.textBoxEpword.TabIndex = 10;
            // 
            // textBoxEuname
            // 
            this.textBoxEuname.BackColor = System.Drawing.Color.White;
            this.textBoxEuname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEuname.ForeColor = System.Drawing.Color.Black;
            this.textBoxEuname.Location = new System.Drawing.Point(553, 178);
            this.textBoxEuname.Name = "textBoxEuname";
            this.textBoxEuname.Size = new System.Drawing.Size(360, 32);
            this.textBoxEuname.TabIndex = 9;
            // 
            // textBoxElname
            // 
            this.textBoxElname.BackColor = System.Drawing.Color.White;
            this.textBoxElname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxElname.ForeColor = System.Drawing.Color.Black;
            this.textBoxElname.Location = new System.Drawing.Point(553, 119);
            this.textBoxElname.Name = "textBoxElname";
            this.textBoxElname.Size = new System.Drawing.Size(360, 32);
            this.textBoxElname.TabIndex = 8;
            // 
            // textBoxEfname
            // 
            this.textBoxEfname.BackColor = System.Drawing.Color.White;
            this.textBoxEfname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEfname.ForeColor = System.Drawing.Color.Black;
            this.textBoxEfname.Location = new System.Drawing.Point(553, 66);
            this.textBoxEfname.Name = "textBoxEfname";
            this.textBoxEfname.Size = new System.Drawing.Size(360, 32);
            this.textBoxEfname.TabIndex = 7;
            // 
            // pictureboxEpic
            // 
            this.pictureboxEpic.Location = new System.Drawing.Point(35, 61);
            this.pictureboxEpic.Name = "pictureboxEpic";
            this.pictureboxEpic.Size = new System.Drawing.Size(235, 208);
            this.pictureboxEpic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureboxEpic.TabIndex = 0;
            this.pictureboxEpic.TabStop = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(35, 298);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(235, 47);
            this.button3.TabIndex = 1;
            this.button3.Text = "Change Picture";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(411, 240);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 29);
            this.label1.TabIndex = 5;
            this.label1.Text = "Password:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(401, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 29);
            this.label2.TabIndex = 4;
            this.label2.Text = "Last Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(397, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 29);
            this.label3.TabIndex = 2;
            this.label3.Text = "First Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(395, 181);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 29);
            this.label4.TabIndex = 3;
            this.label4.Text = "User Name:";
            // 
            // labelClose
            // 
            this.labelClose.AutoSize = true;
            this.labelClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelClose.Location = new System.Drawing.Point(911, 19);
            this.labelClose.Name = "labelClose";
            this.labelClose.Size = new System.Drawing.Size(27, 25);
            this.labelClose.TabIndex = 22;
            this.labelClose.Text = "X";
            this.labelClose.Click += new System.EventHandler(this.labelClose_Click);
            this.labelClose.MouseEnter += new System.EventHandler(this.labelClose_MouseEnter);
            this.labelClose.MouseLeave += new System.EventHandler(this.labelClose_MouseLeave);
            // 
            // labelminimize
            // 
            this.labelminimize.AutoSize = true;
            this.labelminimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelminimize.Location = new System.Drawing.Point(876, 19);
            this.labelminimize.Name = "labelminimize";
            this.labelminimize.Size = new System.Drawing.Size(20, 26);
            this.labelminimize.TabIndex = 23;
            this.labelminimize.Text = "-";
            this.labelminimize.Click += new System.EventHandler(this.labelminimize_Click);
            this.labelminimize.MouseEnter += new System.EventHandler(this.labelminimize_MouseEnter);
            this.labelminimize.MouseLeave += new System.EventHandler(this.labelminimize_MouseLeave);
            // 
            // EDITADMIN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(950, 449);
            this.Controls.Add(this.panel1);
            this.Name = "EDITADMIN";
            this.Text = "EDITADMIN";
            this.Load += new System.EventHandler(this.EDITADMIN_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxedit)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureboxEpic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelepw;
        private System.Windows.Forms.Label labelel;
        private System.Windows.Forms.Label labeleu;
        private System.Windows.Forms.Label labelef;
        private System.Windows.Forms.Button buttoneditpic;
        private System.Windows.Forms.PictureBox pictureBoxedit;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button buttonEditad;
        private System.Windows.Forms.TextBox textBoxEpword;
        private System.Windows.Forms.TextBox textBoxEuname;
        private System.Windows.Forms.TextBox textBoxElname;
        private System.Windows.Forms.TextBox textBoxEfname;
        private System.Windows.Forms.PictureBox pictureboxEpic;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelClose;
        private System.Windows.Forms.Label labelminimize;
    }
}